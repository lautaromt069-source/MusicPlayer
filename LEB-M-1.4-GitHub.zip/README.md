# L.E.B-M 1.4

- Letras **abajo** en el reproductor con seguimiento
- Sin pantalla aparte de letras
- Ajustes rediseñados (tarjetas + header con degradado)
- Logo L.E.B computing
