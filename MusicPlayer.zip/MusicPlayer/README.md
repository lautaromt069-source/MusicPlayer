# L.E.B-M 1.5-beta

## Modo desarrollador
1. Tocá **7 veces** el logo L.E.B (inicio o header de Ajustes).
2. PIN: `lebdev`
3. En Ajustes aparece la sección **DESARROLLADOR**:
   - Forzar PRO
   - Activar/quitar PRO local
   - Estado (canciones, online)
   - Crash log
   - Reset intro
   - Limpiar caché
   - Cerrar modo dev

## PRO (local, sin servidor todavía)
Se activa desde el menú desarrollador. Más adelante: temas, portadas, etc.
