package com.leb.player

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL

object Lyrics {
    data class Line(val timeMs: Long, val text: String)

    private val timeRe = Regex("""\[(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?]""")
    private val tagRe = Regex("""^\[[A-Za-z]{2,}:.*]$""")

    fun parse(raw: String): Pair<List<Line>, Boolean> {
        val out = ArrayList<Line>()
        var synced = false
        for (row in raw.lines()) {
            val ms = timeRe.findAll(row).toList()
            if (ms.isEmpty()) {
                val t = row.trim()
                if (!tagRe.matches(t)) out.add(Line(-1, t))
                continue
            }
            synced = true
            val text = timeRe.replace(row, "").trim()
            for (m in ms) {
                val fr = m.groupValues[3]
                val frMs = if (fr.isEmpty()) 0L else fr.padEnd(3, '0').take(3).toLong()
                out.add(Line(m.groupValues[1].toLong() * 60000 + m.groupValues[2].toLong() * 1000 + frMs, text))
            }
        }
        if (synced) {
            out.removeAll { it.timeMs < 0 }
            out.sortBy { it.timeMs }
        } else {
            while (out.isNotEmpty() && out.last().text.isBlank()) out.removeAt(out.size - 1)
        }
        return Pair(out, synced)
    }

    private fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() }

    fun findInTree(ctx: Context, tree: Uri, title: String, artist: String, keyword: String): String? {
        val tn = norm(title)
        if (tn.length < 2) return null
        val ids = ArrayList<String>()
        ids.add(DocumentsContract.getTreeDocumentId(tree))
        var i = 0
        var lrc: Uri? = null
        var txt: Uri? = null
        while (i < ids.size && i < 300 && lrc == null) {
            val id = ids[i++]
            val kids = DocumentsContract.buildChildDocumentsUriUsingTree(tree, id)
            ctx.contentResolver.query(
                kids,
                arrayOf(
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                    DocumentsContract.Document.COLUMN_MIME_TYPE
                ),
                null, null, null
            )?.use { c ->
                while (c.moveToNext()) {
                    val did = c.getString(0) ?: continue
                    val name = c.getString(1) ?: ""
                    if ((c.getString(2) ?: "") == DocumentsContract.Document.MIME_TYPE_DIR) {
                        ids.add(did); continue
                    }
                    val low = name.lowercase()
                    val isLrc = low.endsWith(".lrc")
                    if (!isLrc && !low.endsWith(".txt")) continue
                    if (keyword.isNotBlank() && !low.contains(keyword.lowercase())) continue
                    val base = norm(name.substringBeforeLast('.'))
                    if (base.contains(tn) || (base.length > 3 && tn.contains(base))) {
                        val u = DocumentsContract.buildDocumentUriUsingTree(tree, did)
                        if (isLrc) lrc = u else if (txt == null) txt = u
                    }
                }
            }
        }
        val pick = lrc ?: txt ?: return null
        return ctx.contentResolver.openInputStream(pick)?.bufferedReader()?.use { it.readText() }
    }

    fun fetchOnline(title: String, artist: String): String? {
        return try {
            var q = "https://lrclib.net/api/search?track_name=" + Uri.encode(title)
            if (artist != "Artista desconocido") q += "&artist_name=" + Uri.encode(artist)
            val c = URL(q).openConnection() as HttpURLConnection
            c.setRequestProperty("User-Agent", "LEB-Player/1.4")
            c.connectTimeout = 8000
            c.readTimeout = 8000
            val arr = JSONArray(c.inputStream.bufferedReader().use { it.readText() })
            var plain: String? = null
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val s = o.optString("syncedLyrics", "")
                if (s.isNotBlank() && s != "null") return s
                val p = o.optString("plainLyrics", "")
                if (plain == null && p.isNotBlank() && p != "null") plain = p
            }
            plain
        } catch (e: Exception) {
            null
        }
    }
}
