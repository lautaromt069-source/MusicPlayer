package com.leb.player

import android.Manifest
import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.ContentUris
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.MediaStore.Audio.Media as AM
import android.text.Editable
import android.text.InputType
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.TextWatcher
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.text.style.StyleSpan
import android.util.LruCache
import android.util.Size
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.LinearInterpolator
import android.widget.*
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import java.io.File
import java.util.concurrent.Executor

class MainActivity : Activity() {

    data class Song(
        val id: Long,
        val title: String,
        val artist: String,
        val album: String,
        val albumId: Long,
        val uri: Uri
    )

    data class Row(
        val t: String,
        val s: String,
        val song: Song? = null,
        val long: (() -> Unit)? = null,
        val click: () -> Unit
    )

    data class LyricLine(val timeMs: Long, val text: String)

    // ── Colores ──────────────────────────────────────────────
    private val ACCENT = Color.parseColor("#8B6CFF")
    private val ACCENT_SOFT = Color.parseColor("#6B4FE0")
    private val BG = Color.parseColor("#0E0E12")
    private val CARD = Color.parseColor("#1A1A22")
    private val GRAY = Color.parseColor("#9A9AA8")
    private val LYRIC_ACTIVE = Color.parseColor("#C4B5FF")
    private val LYRIC_INACTIVE = Color.parseColor("#6B6B7A")

    private val h = Handler(Looper.getMainLooper())
    private val songs = ArrayList<Song>()
    private val cache = LruCache<String, Bitmap>(60)
    private val prefs by lazy { getSharedPreferences("leb", MODE_PRIVATE) }

    private var ctrl: MediaController? = null
    private var tab = 0
    private var fKind = ""
    private var fVal = ""
    private var query = ""
    private var rows: List<Row> = emptyList()
    private var keepPitch = false
    private var rate = 1f
    private var sleepAt = 0L

    // Letras
    private var showLyrics = prefs.getBoolean("leb_show_lyrics", true)
    private var lyricSize = prefs.getInt("leb_lyric_size", 16).toFloat()
    private var lyricKeyword = prefs.getString("leb_keyword", "miapp") ?: "miapp"
    private var autoFilterMiApp = prefs.getBoolean("leb_auto_filter", false)
    private var lyricLines: List<LyricLine> = emptyList()
    private var currentLyricIndex = -1
    private var animBgEnabled = prefs.getBoolean("leb_anim_bg", true)

    // Vistas
    private lateinit var list: ListView
    private lateinit var back: Button
    private lateinit var tabs: List<Button>
    private lateinit var mini: LinearLayout
    private lateinit var miniArt: ImageView
    private lateinit var miniT: TextView
    private lateinit var miniS: TextView
    private lateinit var miniPlay: Button
    private lateinit var full: FrameLayout
    private lateinit var fullContent: LinearLayout
    private lateinit var art: ImageView
    private lateinit var pT: TextView
    private lateinit var pS: TextView
    private lateinit var seek: SeekBar
    private lateinit var timeTv: TextView
    private lateinit var pPlay: Button
    private lateinit var pShuf: Button
    private lateinit var pRep: Button
    private lateinit var favBtn: Button
    private lateinit var sleepBtn: Button
    private lateinit var speedTv: TextView
    private lateinit var lyricsPanel: LinearLayout
    private lateinit var lyricsTv: TextView
    private lateinit var lyricsScroll: ScrollView
    private lateinit var settingsView: LinearLayout
    private lateinit var searchInput: EditText
    private lateinit var animBgView: View

    private var bgAnimator: ValueAnimator? = null

    // ── Helpers ──────────────────────────────────────────────
    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()

    private fun rounded(c: Int, r: Int) = GradientDrawable().apply {
        setColor(c)
        cornerRadius = dp(r).toFloat()
    }

    private fun txt(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(color)
        setSingleLine(true)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun btn(t: String, w: Float = 0f, f: () -> Unit) = Button(this).apply {
        text = t
        setTextColor(Color.WHITE)
        isAllCaps = false
        setBackgroundColor(Color.TRANSPARENT)
        layoutParams = LinearLayout.LayoutParams(if (w > 0) 0 else ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, w)
        setOnClickListener { f() }
    }

    // ── Lifecycle ────────────────────────────────────────────
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Thread.setDefaultUncaughtExceptionHandler { _, _ ->
            try {
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "Se evitó un cierre de L.E.B-M", Toast.LENGTH_SHORT).show()
                }
            } catch (_: Exception) {}
        }
        try {
            val root = FrameLayout(this).apply { setBackgroundColor(BG) }
            root.addView(buildMain())
            root.addView(buildFull())
            root.addView(buildSettings())
            setContentView(root)
            refresh()
        } catch (_: Exception) {
            Toast.makeText(this, "Iniciando L.E.B-M en modo seguro", Toast.LENGTH_SHORT).show()
        }

        val perms = if (Build.VERSION.SDK_INT >= 33)
            arrayOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
        else
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)

        if (hasAudioPerm()) scan()
        if (perms.any { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }) {
            try {
                requestPermissions(perms, 1)
            } catch (_: Exception) {}
        }
        connect()
        tick()
    }

    private fun hasAudioPerm() =
        checkSelfPermission(
            if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
            else Manifest.permission.READ_EXTERNAL_STORAGE
        ) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        if (hasAudioPerm()) scan()
        else {
            refresh()
            Toast.makeText(this, "Necesito permiso para ver tu música", Toast.LENGTH_LONG).show()
        }
    }

    // ── Motor de reproducción ────────────────────────────────
    private val listener = object : Player.Listener {
        override fun onMediaItemTransition(m: MediaItem?, r: Int) {
            currentLyricIndex = -1
            syncUi()
        }
        override fun onIsPlayingChanged(p: Boolean) { syncUi() }
        override fun onPlaybackStateChanged(s: Int) { syncUi() }
    }

    private fun connect() {
        try {
            val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
            val f = MediaController.Builder(this, token).buildAsync()
            f.addListener({
                try {
                    ctrl = f.get()
                    ctrl?.addListener(listener)
                    syncUi()
                } catch (_: Exception) {
                    Toast.makeText(this, "Reproductor en espera", Toast.LENGTH_SHORT).show()
                }
            }, Executor { cmd -> h.post { try { cmd.run() } catch (_: Exception) {} } })
        } catch (_: Exception) {}
    }

    private fun artUri(s: Song) =
        ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), s.albumId)

    private fun item(s: Song) = MediaItem.Builder()
        .setMediaId(s.id.toString())
        .setUri(s.uri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(s.title)
                .setArtist(s.artist)
                .setAlbumTitle(s.album)
                .setArtworkUri(artUri(s))
                .build()
        )
        .build()

    private fun playList(l: List<Song>, i: Int) {
        if (l.isEmpty()) return
        val safeIdx = i.coerceIn(0, l.lastIndex)
        val c = ctrl ?: run {
            connect()
            Toast.makeText(this, "Conectando…", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            c.setMediaItems(l.map { item(it) }, safeIdx, 0L)
            c.prepare()
            c.play()
            applySpeed()
            full.visibility = View.VISIBLE
            startBgAnimation()
        } catch (_: Exception) {
            Toast.makeText(this, "No se pudo reproducir la pista", Toast.LENGTH_SHORT).show()
        }
    }

    private fun current(): Song? =
        ctrl?.currentMediaItem?.mediaId?.let { id -> songs.find { it.id.toString() == id } }

    private fun applySpeed() {
        ctrl?.setPlaybackParameters(PlaybackParameters(rate, if (keepPitch) 1f else rate))
    }

    // ── Biblioteca ───────────────────────────────────────────
    private fun scan() {
        songs.clear()
        try {
            val base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            contentResolver.query(
                base,
                arrayOf(AM._ID, AM.TITLE, AM.ARTIST, AM.ALBUM, AM.ALBUM_ID),
                "${AM.IS_MUSIC}!=0 AND ${AM.DURATION}>=15000",
                null,
                "${AM.TITLE} COLLATE NOCASE ASC"
            )?.use { c ->
                while (c.moveToNext()) {
                    val artist = c.getString(2)?.takeIf { it != "<unknown>" } ?: "Artista desconocido"
                    songs.add(
                        Song(
                            c.getLong(0),
                            c.getString(1) ?: "Sin título",
                            artist,
                            c.getString(3) ?: "Álbum desconocido",
                            c.getLong(4),
                            ContentUris.withAppendedId(base, c.getLong(0))
                        )
                    )
                }
            }
        } catch (_: Exception) {}
        refresh()
        if (songs.isEmpty()) {
            Toast.makeText(this, "No encontré música en tu teléfono", Toast.LENGTH_LONG).show()
        }
    }

    private fun favs(): MutableSet<String> =
        HashSet(prefs.getStringSet("fav", emptySet()) ?: emptySet())

    private fun isFav(s: Song?) = s != null && favs().contains(s.id.toString())

    private fun toggleFav(s: Song?) {
        if (s == null) return
        val set = favs()
        if (!set.remove(s.id.toString())) set.add(s.id.toString())
        prefs.edit().putStringSet("fav", set).apply()
        syncUi()
        if (tab == 3) refresh() else list.invalidateViews()
    }

    private fun refresh() {
        tabs.forEachIndexed { i, b -> b.setTextColor(if (i == tab) ACCENT else GRAY) }
        back.visibility = if (fKind.isEmpty()) View.GONE else View.VISIBLE
        back.text = "‹ Volver   ·   $fVal"

        val q = query.trim()
        fun songRows(l: List<Song>) = l.mapIndexed { i, s ->
            Row(
                s.title,
                s.artist + if (isFav(s)) "  ♥" else "",
                s,
                { toggleFav(s) }
            ) { playList(l, i) }
        }

        rows = when {
            tab == 1 && fKind.isEmpty() ->
                songs.groupBy { it.artist }.map { (k, v) ->
                    Row(k, "${v.size} canciones") {
                        fKind = "a"; fVal = k; tab = 0; refresh()
                    }
                }
            tab == 2 && fKind.isEmpty() ->
                songs.groupBy { it.album }.map { (k, v) ->
                    Row(k, "${v.first().artist} · ${v.size} canciones", v.first()) {
                        fKind = "b"; fVal = k; tab = 0; refresh()
                    }
                }
            tab == 3 -> songRows(songs.filter { isFav(it) })
            else -> songRows(songs.filter {
                val kwOk = !autoFilterMiApp || lyricKeyword.isBlank() ||
                        it.title.contains(lyricKeyword, true) ||
                        it.artist.contains(lyricKeyword, true) ||
                        it.album.contains(lyricKeyword, true)
                kwOk &&
                        (fKind.isEmpty() ||
                                (fKind == "a" && it.artist == fVal) ||
                                (fKind == "b" && it.album == fVal)) &&
                        (q.isEmpty() ||
                                it.title.contains(q, true) ||
                                it.artist.contains(q, true))
            })
        }

        list.adapter = object : BaseAdapter() {
            override fun getCount() = rows.size
            override fun getItem(p: Int) = rows[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun getView(p: Int, v: View?, g: ViewGroup): View {
                val r = rows[p]
                val view = (v as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(16), dp(6), dp(16), dp(6))
                    addView(
                        ImageView(this@MainActivity).apply {
                            scaleType = ImageView.ScaleType.CENTER_CROP
                            background = rounded(CARD, 8)
                            clipToOutline = true
                            outlineProvider = ViewOutlineProvider.BACKGROUND
                        },
                        LinearLayout.LayoutParams(dp(52), dp(52))
                    )
                    addView(
                        LinearLayout(this@MainActivity).apply {
                            orientation = LinearLayout.VERTICAL
                            setPadding(dp(12), 0, 0, 0)
                            addView(txt("", 15f, Color.WHITE))
                            addView(txt("", 12f, GRAY))
                        },
                        LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                    )
                }
                val img = view.getChildAt(0) as ImageView
                val col = view.getChildAt(1) as LinearLayout
                (col.getChildAt(0) as TextView).apply {
                    text = r.t
                    setTextColor(if (r.song != null && r.song.id == current()?.id) ACCENT else Color.WHITE)
                }
                (col.getChildAt(1) as TextView).text = r.s
                img.setImageDrawable(null)
                img.tag = null
                r.song?.let { thumb(it, img, 160) }
                view.setOnClickListener { r.click() }
                view.setOnLongClickListener {
                    r.long?.invoke()
                    r.long != null
                }
                return view
            }
        }
    }

    private fun thumb(s: Song, iv: ImageView, size: Int) {
        val key = s.uri.toString() + size
        iv.tag = key
        cache.get(key)?.let {
            iv.setImageBitmap(it)
            return
        }
        if (Build.VERSION.SDK_INT < 29) return
        Thread {
            try {
                val bm = contentResolver.loadThumbnail(s.uri, Size(size, size), null)
                cache.put(key, bm)
                runOnUiThread { if (iv.tag == key) iv.setImageBitmap(bm) }
            } catch (_: Exception) {}
        }.start()
    }


    /** Logo circular L.E.B dibujado en código (sin recurso externo). */
    private fun lebLogo(sizeDp: Int = 36): View {
        val size = dp(sizeDp)
        return object : View(this) {
            private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = ACCENT
                style = Paint.Style.FILL
            }
            private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                style = Paint.Style.STROKE
                strokeWidth = dp(2).toFloat()
                alpha = 180
            }
            private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textAlign = Paint.Align.CENTER
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }
            override fun onDraw(c: Canvas) {
                val w = width.toFloat()
                val h = height.toFloat()
                val r = minOf(w, h) / 2f
                c.drawCircle(w / 2f, h / 2f, r, bg)
                c.drawCircle(w / 2f, h / 2f, r - ring.strokeWidth, ring)
                tp.textSize = r * 0.55f
                val y = h / 2f - (tp.descent() + tp.ascent()) / 2f
                c.drawText("L.E.B", w / 2f, y, tp)
            }
        }.apply {
            layoutParams = LinearLayout.LayoutParams(size, size).apply { rightMargin = dp(10) }
        }
    }

    // ── UI principal ─────────────────────────────────────────
    private fun buildMain(): View {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(34), 0, 0)
        }

        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(8), dp(12), 0)
        }
        topBar.addView(lebLogo(40))
        val titleCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleCol.addView(txt("L.E.B-M", 22f, Color.WHITE, true))
        titleCol.addView(txt("v2.4 · build fix · letras dinámicas", 11f, GRAY))
        topBar.addView(titleCol, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val settingsBtn = Button(this).apply {
            text = "⚙ Ajustes"
            textSize = 13f
            setTextColor(ACCENT)
            isAllCaps = false
            background = rounded(CARD, 10)
            setPadding(dp(12), dp(6), dp(12), dp(6))
            setOnClickListener { openSettings() }
        }
        topBar.addView(settingsBtn)
        col.addView(topBar)

        val search = EditText(this).apply {
            hint = "Buscar canciones o artistas"
            setHintTextColor(GRAY)
            setTextColor(Color.WHITE)
            setSingleLine(true)
            background = rounded(CARD, 12)
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }.also { searchInput = it }

        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                query = s.toString()
                tab = 0
                refresh()
            }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        col.addView(
            search,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(dp(16), dp(10), dp(16), dp(4)) }
        )

        val bar = LinearLayout(this)
        tabs = listOf("Canciones", "Artistas", "Álbumes", "Favoritas").mapIndexed { i, n ->
            btn(n, 1f) {
                tab = i
                fKind = ""
                fVal = ""
                refresh()
            }.apply { textSize = 13f }
        }
        tabs.forEach { bar.addView(it) }
        col.addView(bar)

        back = btn("‹ Volver") {
            fKind = ""
            fVal = ""
            refresh()
        }.apply {
            setTextColor(ACCENT)
            visibility = View.GONE
        }
        col.addView(back)

        list = ListView(this).apply { divider = null }
        col.addView(
            list,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        )

        mini = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(CARD, 14)
            setPadding(dp(8), dp(8), dp(8), dp(8))
            visibility = View.GONE
        }
        miniArt = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = rounded(Color.parseColor("#2A2A35"), 8)
            clipToOutline = true
            outlineProvider = ViewOutlineProvider.BACKGROUND
        }
        mini.addView(miniArt, LinearLayout.LayoutParams(dp(46), dp(46)))

        val mc = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), 0, 0, 0)
        }
        miniT = txt("", 15f, Color.WHITE, true)
        miniS = txt("", 12f, GRAY)
        mc.addView(miniT)
        mc.addView(miniS)
        mini.addView(mc, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        miniPlay = btn("▶") { togglePlay() }.apply { textSize = 22f }
        mini.addView(miniPlay)
        mini.setOnClickListener {
            full.visibility = View.VISIBLE
            startBgAnimation()
        }
        col.addView(
            mini,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(dp(10), dp(4), dp(10), dp(10)) }
        )
        return col
    }

    // ── Reproductor completo + fondo animado ─────────────────
    private fun buildFull(): View {
        full = FrameLayout(this).apply {
            visibility = View.GONE
            isClickable = true
        }

        // Fondo animado
        animBgView = View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(
                    Color.parseColor("#1A1030"),
                    Color.parseColor("#0E0E12"),
                    Color.parseColor("#12182A")
                )
            )
        }
        full.addView(
            animBgView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        fullContent = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(34), dp(22), dp(10))
            setBackgroundColor(Color.TRANSPARENT)
        }

        fullContent.addView(btn("⌄  Cerrar") {
            full.visibility = View.GONE
            stopBgAnimation()
        })

        
        val fullLogoRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(4), 0, dp(4))
            addView(lebLogo(28))
            addView(txt("L.E.B", 14f, ACCENT, true))
        }
        fullContent.addView(fullLogoRow)

art = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = rounded(CARD, 20)
            clipToOutline = true
            outlineProvider = ViewOutlineProvider.BACKGROUND
        }
        fullContent.addView(
            art,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(240)
            ).apply { topMargin = dp(6) }
        )

        pT = txt("", 22f, Color.WHITE, true).apply { setPadding(0, dp(14), 0, 0) }
        pS = txt("", 15f, GRAY)
        fullContent.addView(pT)
        fullContent.addView(pS)

        seek = SeekBar(this)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) {
                if (user) ctrl?.seekTo(p.toLong())
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        fullContent.addView(seek)

        timeTv = txt("0:00 / 0:00", 12f, GRAY).apply { gravity = Gravity.CENTER }
        fullContent.addView(timeTv)

        val ctl = LinearLayout(this).apply { gravity = Gravity.CENTER }
        pShuf = btn("🔀", 1f) {
            ctrl?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled }
            syncUi()
        }
        pRep = btn("🔁", 1f) {
            ctrl?.let { it.repeatMode = (it.repeatMode + 1) % 3 }
            syncUi()
        }
        pPlay = btn("▶", 1.3f) { togglePlay() }.apply {
            textSize = 32f
            setTextColor(ACCENT)
        }
        ctl.addView(pShuf)
        ctl.addView(btn("⏮", 1f) { ctrl?.seekToPrevious() }.apply { textSize = 24f })
        ctl.addView(pPlay)
        ctl.addView(btn("⏭", 1f) { ctrl?.seekToNext() }.apply { textSize = 24f })
        ctl.addView(pRep)
        fullContent.addView(ctl)

        speedTv = txt("Velocidad: 1.00x", 13f, Color.WHITE).apply { gravity = Gravity.CENTER }
        fullContent.addView(speedTv)

        val sp = LinearLayout(this)
        sp.addView(btn("🐢 Slowed", 1f) { setRate(0.8f) })
        sp.addView(btn("Normal", 1f) { setRate(1f) })
        sp.addView(btn("🐇 Sped up", 1f) { setRate(1.25f) })
        fullContent.addView(sp)

        val ex = LinearLayout(this).apply { gravity = Gravity.CENTER }
        favBtn = btn("♡", 1f) { toggleFav(current()) }.apply { textSize = 24f }
        sleepBtn = btn("⏲ Dormir", 1f) { sleepDialog() }
        ex.addView(favBtn)
        ex.addView(sleepBtn)
        ex.addView(btn("Tono", 1f) {
            keepPitch = !keepPitch
            applySpeed()
            Toast.makeText(
                this,
                if (keepPitch) "Tono original" else "El tono cambia con la velocidad",
                Toast.LENGTH_SHORT
            ).show()
        })
        fullContent.addView(ex)

        // Panel de letras
        lyricsPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.parseColor("#1A1A28"), 14)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            visibility = if (showLyrics) View.VISIBLE else View.GONE
        }

        val lHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val lTitle = txt("Letra dinámica", 12f, ACCENT, true)
        lHeader.addView(lTitle, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val editLyricBtn = Button(this).apply {
            text = "Editar"
            textSize = 11f
            setTextColor(Color.WHITE)
            isAllCaps = false
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener { current()?.let { showLyricEditor(it) } }
        }
        lHeader.addView(editLyricBtn)
        lyricsPanel.addView(lHeader)

        lyricsScroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
        }
        lyricsTv = TextView(this).apply {
            text = "Sin letra cargada para esta canción."
            textSize = lyricSize
            setTextColor(LYRIC_INACTIVE)
            setLineSpacing(dp(6).toFloat(), 1.2f)
            setPadding(0, dp(4), 0, dp(8))
        }
        lyricsScroll.addView(lyricsTv)
        lyricsPanel.addView(
            lyricsScroll,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
            ).apply { topMargin = dp(4) }
        )
        fullContent.addView(
            lyricsPanel,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
            ).apply { topMargin = dp(8) }
        )

        full.addView(
            fullContent,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        return full
    }

    // ── Animación de fondo ───────────────────────────────────
    private fun startBgAnimation() {
        if (!animBgEnabled) {
            animBgView.setBackgroundColor(BG)
            return
        }
        stopBgAnimation()
        val colors = arrayOf(
            intArrayOf(Color.parseColor("#1A1030"), Color.parseColor("#0E0E12"), Color.parseColor("#12182A")),
            intArrayOf(Color.parseColor("#20103A"), Color.parseColor("#120E1A"), Color.parseColor("#0E1A2A")),
            intArrayOf(Color.parseColor("#181428"), Color.parseColor("#0A0A14"), Color.parseColor("#141A28")),
            intArrayOf(Color.parseColor("#221038"), Color.parseColor("#0E0C18"), Color.parseColor("#101828"))
        )
        var idx = 0
        bgAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 4500
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { anim ->
                val t = anim.animatedFraction
                val from = colors[idx % colors.size]
                val to = colors[(idx + 1) % colors.size]
                val eval = ArgbEvaluator()
                val c1 = eval.evaluate(t, from[0], to[0]) as Int
                val c2 = eval.evaluate(t, from[1], to[1]) as Int
                val c3 = eval.evaluate(t, from[2], to[2]) as Int
                animBgView.background = GradientDrawable(
                    GradientDrawable.Orientation.TL_BR,
                    intArrayOf(c1, c2, c3)
                )
            }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationRepeat(animation: android.animation.Animator) {
                    idx = (idx + 1) % colors.size
                }
            })
            start()
        }
    }

    private fun stopBgAnimation() {
        bgAnimator?.cancel()
        bgAnimator = null
    }

    // ── Letras (carga + seguimiento) ─────────────────────────
    private fun lyricKey(s: Song?) = if (s == null) "" else "leb_lyric_${s.id}"

    private fun parseLrc(raw: String): List<LyricLine> {
        val lines = mutableListOf<LyricLine>()
        val regex = Regex("""\[(\d{1,2}):(\d{2})(?:\.(\d{1,3}))?\]\s*(.*)""")
        for (line in raw.lines()) {
            val m = regex.find(line.trim())
            if (m != null) {
                val min = m.groupValues[1].toLongOrNull() ?: 0
                val sec = m.groupValues[2].toLongOrNull() ?: 0
                val msPart = m.groupValues[3]
                val ms = when {
                    msPart.isEmpty() -> 0L
                    msPart.length == 1 -> msPart.toLong() * 100
                    msPart.length == 2 -> msPart.toLong() * 10
                    else -> msPart.take(3).toLong()
                }
                val text = m.groupValues[4].trim()
                if (text.isNotEmpty()) {
                    lines.add(LyricLine(min * 60000 + sec * 1000 + ms, text))
                }
            }
        }
        return lines.sortedBy { it.timeMs }
    }

    private fun loadLyrics(s: Song?): Pair<String, List<LyricLine>> {
        if (s == null) return "Reproduce una canción para ver su letra." to emptyList()

        // 1) Letra personalizada guardada
        val custom = prefs.getString(lyricKey(s), null)
        if (!custom.isNullOrBlank()) {
            val parsed = parseLrc(custom)
            return if (parsed.isNotEmpty()) custom to parsed
            else custom to custom.lines().filter { it.isNotBlank() }.map { LyricLine(0, it) }
        }

        // 2) Buscar archivo .lrc / .txt
        val baseDirs = listOfNotNull(
            getExternalFilesDir(null),
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC),
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        )
        val cleanName = s.title.replace(Regex("""[\\/:*?"<>|]"""), "").trim()
        for (dir in baseDirs) {
            if (!dir.exists()) continue
            val candidates = listOf(
                File(dir, "$cleanName.lrc"),
                File(dir, "$cleanName.txt"),
                File(File(dir, lyricKeyword), "$cleanName.lrc"),
                File(File(dir, lyricKeyword), "$cleanName.txt")
            )
            val found = candidates.firstOrNull { it.exists() && it.canRead() }
            if (found != null) {
                val raw = found.readText()
                val parsed = parseLrc(raw)
                return if (parsed.isNotEmpty()) raw to parsed
                else {
                    val plain = raw.lines().joinToString("\n") {
                        it.replace(Regex("""^\[[0-9:.]+\]\s*"""), "")
                    }.trim()
                    plain to plain.lines().filter { it.isNotBlank() }.map { LyricLine(0, it) }
                }
            }
        }

        return "Sin letra para \"${s.title}\".\nToca \"Editar\" para agregarla o coloca un archivo .lrc" to emptyList()
    }

    private fun refreshLyrics(s: Song?) {
        if (!::lyricsPanel.isInitialized || !::lyricsTv.isInitialized) return
        lyricsPanel.visibility = if (showLyrics) View.VISIBLE else View.GONE
        lyricsTv.textSize = lyricSize

        val (display, lines) = loadLyrics(s)
        lyricLines = lines
        currentLyricIndex = -1

        if (lines.isEmpty() || lines.all { it.timeMs == 0L }) {
            // Texto plano
            lyricsTv.text = display
            lyricsTv.setTextColor(Color.WHITE)
        } else {
            // LRC sincronizado → se actualiza en tick()
            updateLyricHighlight(-1)
        }
    }

    private fun updateLyricHighlight(index: Int) {
        if (lyricLines.isEmpty()) return
        currentLyricIndex = index

        val sb = SpannableStringBuilder()
        lyricLines.forEachIndexed { i, line ->
            if (i > 0) sb.append("\n")
            val start = sb.length
            sb.append(line.text)
            val end = sb.length
            if (i == index) {
                sb.setSpan(ForegroundColorSpan(LYRIC_ACTIVE), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                sb.setSpan(StyleSpan(Typeface.BOLD), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                sb.setSpan(RelativeSizeSpan(1.18f), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            } else {
                val dim = if (index >= 0 && kotlin.math.abs(i - index) <= 1) Color.parseColor("#9A90B8") else LYRIC_INACTIVE
                sb.setSpan(ForegroundColorSpan(dim), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
        }
        lyricsTv.text = sb

        // Auto-scroll hacia la línea activa
        if (index >= 0 && ::lyricsScroll.isInitialized) {
            lyricsTv.post {
                try {
                    val layout = lyricsTv.layout ?: return@post
                    if (index >= layout.lineCount) return@post
                    val y = layout.getLineTop(index)
                    val centerOffset = lyricsScroll.height / 3
                    lyricsScroll.smoothScrollTo(0, (y - centerOffset).coerceAtLeast(0))
                } catch (_: Exception) {}
            }
        }
    }

    private fun showLyricEditor(s: Song) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(12), dp(18), dp(6))
        }
        val input = EditText(this).apply {
            setText(prefs.getString(lyricKey(s), "") ?: "")
            hint = "Pega la letra (soporta formato LRC con [mm:ss.xx])"
            minLines = 8
            gravity = Gravity.TOP or Gravity.START
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            setTextColor(Color.WHITE)
            setHintTextColor(GRAY)
        }
        box.addView(input)
        AlertDialog.Builder(this)
            .setTitle("Letra · ${s.title}")
            .setView(box)
            .setPositiveButton("Guardar") { _, _ ->
                prefs.edit().putString(lyricKey(s), input.text.toString().trim()).apply()
                refreshLyrics(s)
                Toast.makeText(this, "Letra guardada", Toast.LENGTH_SHORT).show()
            }
            .setNeutralButton("Borrar") { _, _ ->
                prefs.edit().remove(lyricKey(s)).apply()
                refreshLyrics(s)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ── Ajustes ──────────────────────────────────────────────
    private fun buildSettings(): View {
        settingsView = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
            setPadding(dp(20), dp(34), dp(20), dp(16))
            visibility = View.GONE
            isClickable = true
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        top.addView(btn("‹ Volver") { settingsView.visibility = View.GONE }.apply { setTextColor(ACCENT) })
        top.addView(
            txt("Ajustes · v2.4", 22f, Color.WHITE, true).apply {
                setPadding(dp(8), 0, 0, 0)
            }
        )
        settingsView.addView(top)

        val scroll = ScrollView(this)
        val inner = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(14), 0, dp(24))
        }

        // Sección Letras
        val secLyrics = txt("LETRAS", 13f, ACCENT, true)
        inner.addView(secLyrics, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(10) })

        val swLyrics = Switch(this).apply {
            text = "Mostrar letras en reproductor"
            setTextColor(Color.WHITE)
            isChecked = showLyrics
        }
        inner.addView(swLyrics, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(10) })

        val swFilter = Switch(this).apply {
            text = "Filtrar biblioteca con palabra clave"
            setTextColor(Color.WHITE)
            isChecked = autoFilterMiApp
        }
        inner.addView(swFilter, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(10) })

        val kwLabel = txt("Palabra clave / carpeta de letras:", 13f, GRAY)
        inner.addView(kwLabel, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(4) })

        val kwInput = EditText(this).apply {
            setText(lyricKeyword)
            setTextColor(Color.WHITE)
            background = rounded(CARD, 10)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setSingleLine(true)
        }
        inner.addView(kwInput, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(14) })

        val sizeLabel = txt("Tamaño de letra: ${lyricSize.toInt()}sp", 13f, Color.WHITE)
        inner.addView(sizeLabel, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(4) })

        val seekSize = SeekBar(this).apply {
            max = 28
            progress = (lyricSize.toInt() - 10).coerceIn(0, 28)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    val sp = p + 10
                    sizeLabel.text = "Tamaño de letra: ${sp}sp"
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        inner.addView(seekSize, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(18) })

        // Sección Visual
        val secVisual = txt("VISUAL", 13f, ACCENT, true)
        inner.addView(secVisual, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(10) })

        val swAnim = Switch(this).apply {
            text = "Fondos animados en reproductor"
            setTextColor(Color.WHITE)
            isChecked = animBgEnabled
        }
        inner.addView(swAnim, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(20) })

        val saveBtn = Button(this).apply {
            text = "Guardar ajustes"
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = rounded(ACCENT, 12)
            setPadding(0, dp(14), 0, dp(14))
            setOnClickListener {
                val chosenKw = kwInput.text.toString().trim().ifEmpty { "miapp" }
                val chosenSize = (seekSize.progress + 10).toFloat()
                showLyrics = swLyrics.isChecked
                autoFilterMiApp = swFilter.isChecked
                lyricKeyword = chosenKw
                lyricSize = chosenSize
                animBgEnabled = swAnim.isChecked

                prefs.edit()
                    .putBoolean("leb_show_lyrics", showLyrics)
                    .putBoolean("leb_auto_filter", autoFilterMiApp)
                    .putString("leb_keyword", lyricKeyword)
                    .putInt("leb_lyric_size", lyricSize.toInt())
                    .putBoolean("leb_anim_bg", animBgEnabled)
                    .apply()

                refreshLyrics(current())
                refresh()
                if (full.visibility == View.VISIBLE) {
                    if (animBgEnabled) startBgAnimation() else stopBgAnimation()
                }
                settingsView.visibility = View.GONE
                Toast.makeText(
                    this@MainActivity,
                    "Ajustes guardados",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
        inner.addView(saveBtn, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(12) })

        val rescanBtn = Button(this).apply {
            text = "Volver a escanear música"
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = rounded(CARD, 12)
            setPadding(0, dp(14), 0, dp(14))
            setOnClickListener {
                if (hasAudioPerm()) scan()
                else Toast.makeText(this@MainActivity, "Sin permiso de audio", Toast.LENGTH_SHORT).show()
            }
        }
        inner.addView(rescanBtn, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ))

        // Info
        val info = txt("L.E.B-M  ·  v2.4\nLetras dinámicas · Logo L.E.B · Fondos animados", 12f, GRAY)
        info.setSingleLine(false)
        info.gravity = Gravity.CENTER
        inner.addView(info, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(28) })

        scroll.addView(inner)
        settingsView.addView(
            scroll,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        )
        return settingsView
    }

    private fun openSettings() {
        settingsView.visibility = View.VISIBLE
    }

    private fun setRate(r: Float) {
        rate = r
        speedTv.text = "Velocidad: %.2fx".format(rate)
        applySpeed()
    }

    private fun togglePlay() {
        ctrl?.let { if (it.isPlaying) it.pause() else it.play() }
    }

    private fun sleepDialog() {
        val o = arrayOf("15 minutos", "30 minutos", "45 minutos", "1 hora", "Cancelar temporizador")
        val m = intArrayOf(15, 30, 45, 60, 0)
        AlertDialog.Builder(this).setTitle("Temporizador para dormir").setItems(o) { _, i ->
            sleepAt = if (m[i] == 0) 0L else System.currentTimeMillis() + m[i] * 60000L
            if (m[i] == 0) sleepBtn.text = "⏲ Dormir"
        }.show()
    }

    private fun syncUi() {
        val c = ctrl ?: return
        val s = current()
        mini.visibility = if (s != null) View.VISIBLE else View.GONE

        if (s != null && pT.text.toString() != s.title) {
            pT.text = s.title
            pS.text = s.artist
            miniT.text = s.title
            miniS.text = s.artist
            art.setImageDrawable(null)
            miniArt.setImageDrawable(null)
            thumb(s, art, 600)
            thumb(s, miniArt, 160)
            refreshLyrics(s)
            list.invalidateViews()
        } else {
            refreshLyrics(s)
        }

        val icon = if (c.isPlaying) "⏸" else "▶"
        pPlay.text = icon
        miniPlay.text = icon
        pShuf.alpha = if (c.shuffleModeEnabled) 1f else 0.4f
        pRep.alpha = if (c.repeatMode != Player.REPEAT_MODE_OFF) 1f else 0.4f
        pRep.text = if (c.repeatMode == Player.REPEAT_MODE_ONE) "🔂" else "🔁"
        favBtn.text = if (isFav(s)) "♥" else "♡"
    }

    private fun fmt(ms: Long) = "%d:%02d".format(ms / 60000, (ms / 1000) % 60)

    private fun tick() {
        val c = ctrl
        if (c != null && c.currentMediaItem != null) {
            val d = c.duration
            if (d > 0) {
                seek.max = d.toInt()
                seek.progress = c.currentPosition.toInt()
                timeTv.text = "${fmt(c.currentPosition)} / ${fmt(d)}"
            }

            // Seguimiento de letras
            if (showLyrics && lyricLines.isNotEmpty() && lyricLines.any { it.timeMs > 0 }) {
                val pos = c.currentPosition
                var idx = -1
                for (i in lyricLines.indices) {
                    if (lyricLines[i].timeMs <= pos) idx = i
                    else break
                }
                if (idx != currentLyricIndex) {
                    updateLyricHighlight(idx)
                }
            }
        }

        if (sleepAt > 0) {
            val left = sleepAt - System.currentTimeMillis()
            if (left <= 0) {
                sleepAt = 0
                ctrl?.pause()
                sleepBtn.text = "⏲ Dormir"
            } else {
                sleepBtn.text = "⏲ ${left / 60000 + 1} min"
            }
        }
        h.postDelayed({ tick() }, 400)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            ::settingsView.isInitialized && settingsView.visibility == View.VISIBLE ->
                settingsView.visibility = View.GONE
            full.visibility == View.VISIBLE -> {
                full.visibility = View.GONE
                stopBgAnimation()
            }
            fKind.isNotEmpty() -> {
                fKind = ""
                fVal = ""
                refresh()
            }
            else -> super.onBackPressed()
        }
    }

    override fun onDestroy() {
        stopBgAnimation()
        h.removeCallbacksAndMessages(null)
        ctrl?.release()
        super.onDestroy()
    }
}
