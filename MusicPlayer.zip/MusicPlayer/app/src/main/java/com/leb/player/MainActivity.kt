package com.leb.player

import android.Manifest
import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.MediaStore.Audio.Media as AM
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.TextWatcher
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.text.style.StyleSpan
import android.util.Log
import android.util.LruCache
import android.util.Size
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.LinearInterpolator
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.io.File
import kotlin.math.abs

class MainActivity : Activity() {

    data class Song(
        val id: Long,
        val title: String,
        val artist: String,
        val album: String,
        val albumId: Long,
        val uri: Uri
    )

    data class Row(
        val t: String,
        val s: String,
        val song: Song? = null,
        val long: (() -> Unit)? = null,
        val click: () -> Unit
    )

    data class LyricLine(val timeMs: Long, val text: String)

    private val ACCENT = Color.parseColor("#8B6CFF")
    private val BG = Color.parseColor("#0E0E12")
    private val CARD = Color.parseColor("#1A1A22")
    private val GRAY = Color.parseColor("#9A9AA8")
    private val LYRIC_ACTIVE = Color.parseColor("#C4B5FF")
    private val LYRIC_INACTIVE = Color.parseColor("#6B6B7A")

    private val h = Handler(Looper.getMainLooper())
    private val songs = ArrayList<Song>()
    private val cache = LruCache<String, Bitmap>(64)
    private val prefs by lazy { getSharedPreferences("leb_prefs_v22", MODE_PRIVATE) }

    private var mediaPlayer: MediaPlayer? = null
    private var isPlayingState = false
    private var isPreparedState = false
    private var queue: List<Song> = emptyList()
    private var queueIndex = -1
    private var currentSong: Song? = null

    private var tab = 0
    private var fKind = ""
    private var fVal = ""
    private var query = ""
    private var rows: List<Row> = emptyList()

    private var shuffleEnabled = false
    private var repeatMode = 0
    private var keepPitch = true
    private var rate = 1.0f
    private var sleepAt = 0L
    private var statusMessage = "Listo para reproducir"

    private var showLyrics = true
    private var lyricSize = 16f
    private var lyricKeyword = "miapp"
    private var autoFilterMiApp = false
    private var lyricLines: List<LyricLine> = emptyList()
    private var currentLyricIndex = -1
    private var animBgEnabled = true

    private var listView: ListView? = null
    private var backBtn: Button? = null
    private var tabs: List<Button> = emptyList()
    private var statusTv: TextView? = null
    private var miniBar: LinearLayout? = null
    private var miniArt: ImageView? = null
    private var miniTitle: TextView? = null
    private var miniSub: TextView? = null
    private var miniPlayBtn: Button? = null

    private var fullPlayer: FrameLayout? = null
    private var artView: ImageView? = null
    private var pTitle: TextView? = null
    private var pArtist: TextView? = null
    private var seekBar: SeekBar? = null
    private var timeTv: TextView? = null
    private var pPlayBtn: Button? = null
    private var pShufBtn: Button? = null
    private var pRepBtn: Button? = null
    private var favBtn: Button? = null
    private var sleepBtn: Button? = null
    private var speedTv: TextView? = null
    private var lyricsPanel: LinearLayout? = null
    private var lyricsTv: TextView? = null
    private var lyricsScroll: ScrollView? = null
    private var settingsView: LinearLayout? = null
    private var animBgView: View? = null

    private var bgAnimator: ValueAnimator? = null
    private var isUserSeeking = false

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt().coerceAtLeast(1)

    private fun rounded(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun txt(textVal: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = textVal
        textSize = size
        setTextColor(color)
        setSingleLine(true)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun btn(label: String, weight: Float = 0f, action: () -> Unit) = Button(this).apply {
        text = label
        setTextColor(Color.WHITE)
        isAllCaps = false
        setBackgroundColor(Color.TRANSPARENT)
        layoutParams = LinearLayout.LayoutParams(
            if (weight > 0f) 0 else ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            weight
        )
        setOnClickListener {
            try {
                action()
            } catch (e: Exception) {
                Log.e("LEB_M", "Error en botón $label", e)
                showToast("Acción segura: $label")
            }
        }
    }

    private fun showToast(msg: String) {
        try {
            runOnUiThread {
                Toast.makeText(this@MainActivity, msg, Toast.LENGTH_SHORT).show()
            }
        } catch (_: Exception) {}
    }

    private fun loadSavedPrefs() {
        try {
            showLyrics = prefs.getBoolean("leb_show_lyrics", true)
            lyricSize = prefs.getInt("leb_lyric_size", 16).toFloat().coerceIn(10f, 38f)
            lyricKeyword = prefs.getString("leb_keyword", "miapp") ?: "miapp"
            autoFilterMiApp = prefs.getBoolean("leb_auto_filter", false)
            animBgEnabled = prefs.getBoolean("leb_anim_bg", true)
        } catch (_: Exception) {}
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Thread.setDefaultUncaughtExceptionHandler { _, throwable ->
            Log.e("LEB_M", "Excepción capturada", throwable)
            showToast("Se evitó cerrar L.E.B-M")
        }

        loadSavedPrefs()

        try {
            val root = FrameLayout(this).apply { setBackgroundColor(BG) }
            root.addView(buildMain())
            root.addView(buildFull())
            root.addView(buildSettings())
            setContentView(root)
            refresh()
            syncUi()
        } catch (e: Exception) {
            Log.e("LEB_M", "Fallo al crear vista principal", e)
            setContentView(buildEmergencyView(e.message ?: "Error de interfaz"))
        }

        val perms = requiredPermissions()
        if (hasAudioPerm()) {
            scanSongsSafe()
        } else if (perms.isNotEmpty()) {
            try {
                requestPermissions(perms, 101)
            } catch (_: Exception) {
                statusMessage = "Activá permisos de música en Ajustes del sistema"
                refresh()
            }
        }

        startTickLoop()
    }

    private fun buildEmergencyView(reason: String): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(BG)
            setPadding(dp(24), dp(24), dp(24), dp(24))
            addView(txt("L.E.B-M · Modo Seguro", 22f, ACCENT, true))
            addView(txt("La app se abrió sin cerrarse.", 14f, Color.WHITE).apply {
                setPadding(0, dp(8), 0, dp(4))
            })
            addView(txt(reason, 12f, GRAY).apply {
                setSingleLine(false)
                gravity = Gravity.CENTER
            })
            addView(Button(this@MainActivity).apply {
                text = "Reintentar abrir reproductor"
                isAllCaps = false
                setTextColor(Color.WHITE)
                background = rounded(ACCENT, 12)
                setOnClickListener { recreate() }
            }.apply { topMargin = dp(16) })
        }
    }

    private fun requiredPermissions(): Array<String> {
        return if (Build.VERSION.SDK_INT >= 33) {
            arrayOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
        } else {
            arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
    }

    private fun hasAudioPerm(): Boolean {
        val perm = if (Build.VERSION.SDK_INT >= 33) {
            Manifest.permission.READ_MEDIA_AUDIO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
        return checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        try {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        } catch (_: Exception) {}

        if (hasAudioPerm()) {
            scanSongsSafe()
        } else {
            statusMessage = "Sin permiso de audio · Podés abrir Ajustes o escanear luego"
            refresh()
        }
    }

    private fun ensurePlayer(): MediaPlayer {
        mediaPlayer?.let { return it }
        return MediaPlayer().apply {
            setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            setOnPreparedListener { mp ->
                isPreparedState = true
                applyPlaybackSpeed(mp)
                mp.start()
                isPlayingState = true
                statusMessage = "Reproduciendo"
                syncUi()
            }
            setOnCompletionListener {
                isPlayingState = false
                handleTrackEnded()
            }
            setOnErrorListener { _, what, extra ->
                Log.w("LEB_M", "MediaPlayer error what=$what extra=$extra")
                isPreparedState = false
                isPlayingState = false
                statusMessage = "Error de pista ($what)"
                syncUi()
                true
            }
            mediaPlayer = this
        }
    }

    private fun applyPlaybackSpeed(mp: MediaPlayer? = mediaPlayer) {
        if (Build.VERSION.SDK_INT >= 23 && mp != null && isPreparedState) {
            try {
                val params = mp.playbackParams
                params.speed = rate.coerceIn(0.5f, 2.0f)
                params.pitch = if (keepPitch) 1.0f else rate.coerceIn(0.5f, 2.0f)
                mp.playbackParams = params
            } catch (_: Exception) {}
        }
    }

    private fun playSongAt(list: List<Song>, index: Int) {
        if (list.isEmpty()) {
            showToast("No hay canciones en esta lista")
            return
        }
        val safeIdx = index.coerceIn(0, list.lastIndex)
        queue = list
        queueIndex = safeIdx
        val target = queue[queueIndex]
        currentSong = target
        currentLyricIndex = -1

        fullPlayer?.visibility = View.VISIBLE
        if (animBgEnabled) startBgAnimation()
        syncUi()

        try {
            val mp = ensurePlayer()
            isPreparedState = false
            isPlayingState = false
            mp.reset()
            mp.setDataSource(this, target.uri)
            statusMessage = "Cargando pista…"
            mp.prepareAsync()
        } catch (e: Exception) {
            Log.e("LEB_M", "Error al iniciar pista ${target.title}", e)
            statusMessage = "No se pudo abrir el archivo de audio"
            showToast("No se pudo reproducir: ${target.title}")
            syncUi()
        }
    }

    private fun handleTrackEnded() {
        if (repeatMode == 2 && currentSong != null) {
            playSongAt(queue.ifEmpty { listOf(currentSong!!) }, queueIndex.coerceAtLeast(0))
            return
        }
        if (queue.isNotEmpty()) {
            val nextIdx = if (shuffleEnabled) {
                (queue.indices).random()
            } else if (queueIndex + 1 < queue.size) {
                queueIndex + 1
            } else if (repeatMode == 1) {
                0
            } else {
                -1
            }
            if (nextIdx >= 0) {
                playSongAt(queue, nextIdx)
                return
            }
        }
        isPlayingState = false
        statusMessage = "Finalizado"
        syncUi()
    }

    private fun togglePlay() {
        val mp = mediaPlayer
        if (mp != null && isPreparedState) {
            try {
                if (mp.isPlaying) {
                    mp.pause()
                    isPlayingState = false
                    statusMessage = "Pausado"
                } else {
                    applyPlaybackSpeed(mp)
                    mp.start()
                    isPlayingState = true
                    statusMessage = "Reproduciendo"
                }
                syncUi()
                return
            } catch (_: Exception) {}
        }

        val fallbackList = if (queue.isNotEmpty()) queue else songs
        if (fallbackList.isNotEmpty()) {
            playSongAt(fallbackList, queueIndex.coerceAtLeast(0))
        } else {
            showToast("Escaneá tu música primero para reproducir")
        }
    }

    private fun skipNext() {
        if (queue.isEmpty()) return
        val next = if (shuffleEnabled) (queue.indices).random() else (queueIndex + 1) % queue.size
        playSongAt(queue, next)
    }

    private fun skipPrev() {
        if (queue.isEmpty()) return
        val prev = if (queueIndex - 1 >= 0) queueIndex - 1 else queue.lastIndex
        playSongAt(queue, prev)
    }

    private fun setRate(newRate: Float) {
        rate = newRate
        speedTv?.text = "Velocidad: %.2fx".format(rate)
        applyPlaybackSpeed()
    }

    private fun scanSongsSafe() {
        songs.clear()
        try {
            val base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            val projection = arrayOf(AM._ID, AM.TITLE, AM.ARTIST, AM.ALBUM, AM.ALBUM_ID)
            val selection = "${AM.IS_MUSIC}!=0 AND ${AM.DURATION}>=10000"
            contentResolver.query(
                base,
                projection,
                selection,
                null,
                "${AM.TITLE} COLLATE NOCASE ASC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndex(AM._ID)
                val titleCol = cursor.getColumnIndex(AM.TITLE)
                val artistCol = cursor.getColumnIndex(AM.ARTIST)
                val albumCol = cursor.getColumnIndex(AM.ALBUM)
                val albumIdCol = cursor.getColumnIndex(AM.ALBUM_ID)

                while (cursor.moveToNext()) {
                    val id = if (idCol >= 0) cursor.getLong(idCol) else cursor.position.toLong()
                    val title = if (titleCol >= 0) cursor.getString(titleCol)?.takeIf { it.isNotBlank() } else null
                    val artistRaw = if (artistCol >= 0) cursor.getString(artistCol) else null
                    val artist = artistRaw?.takeIf { it != "<unknown>" && it.isNotBlank() } ?: "Artista desconocido"
                    val album = if (albumCol >= 0) cursor.getString(albumCol)?.takeIf { it.isNotBlank() } else null
                    val albumId = if (albumIdCol >= 0) cursor.getLong(albumIdCol) else 0L
                    val uri = ContentUris.withAppendedId(base, id)

                    songs.add(
                        Song(
                            id = id,
                            title = title ?: "Pista ${id}",
                            artist = artist,
                            album = album ?: "Álbum desconocido",
                            albumId = albumId,
                            uri = uri
                        )
                    )
                }
            }
            statusMessage = if (songs.isEmpty()) {
                "No se encontraron pistas de audio en el dispositivo"
            } else {
                "${songs.size} canciones listas"
            }
        } catch (e: Exception) {
            Log.e("LEB_M", "Error consultando MediaStore", e)
            statusMessage = "Revisá el permiso de música si no ves pistas"
        }
        refresh()
    }

    private fun favs(): MutableSet<String> {
        return try {
            HashSet(prefs.getStringSet("fav_ids", emptySet()) ?: emptySet())
        } catch (_: Exception) {
            HashSet()
        }
    }

    private fun isFav(s: Song?) = s != null && favs().contains(s.id.toString())

    private fun toggleFav(s: Song?) {
        if (s == null) return
        val set = favs()
        if (!set.remove(s.id.toString())) set.add(s.id.toString())
        prefs.edit().putStringSet("fav_ids", set).apply()
        syncUi()
        if (tab == 3) refresh() else listView?.invalidateViews()
    }

    private fun refresh() {
        tabs.forEachIndexed { idx, button ->
            button.setTextColor(if (idx == tab) ACCENT else GRAY)
        }
        backBtn?.apply {
            visibility = if (fKind.isEmpty()) View.GONE else View.VISIBLE
            text = "‹ Volver · $fVal"
        }
        statusTv?.text = statusMessage

        val q = query.trim()
        fun makeSongRows(list: List<Song>) = list.mapIndexed { idx, s ->
            Row(
                t = s.title,
                s = s.artist + if (isFav(s)) "  ♥" else "",
                song = s,
                long = { toggleFav(s) },
                click = { playSongAt(list, idx) }
            )
        }

        rows = when {
            tab == 1 && fKind.isEmpty() ->
                songs.groupBy { it.artist }.map { (artistName, group) ->
                    Row(artistName, "${group.size} canciones") {
                        fKind = "a"
                        fVal = artistName
                        tab = 0
                        refresh()
                    }
                }
            tab == 2 && fKind.isEmpty() ->
                songs.groupBy { it.album }.map { (albumName, group) ->
                    Row(albumName, "${group.first().artist} · ${group.size} canciones", group.first()) {
                        fKind = "b"
                        fVal = albumName
                        tab = 0
                        refresh()
                    }
                }
            tab == 3 -> makeSongRows(songs.filter { isFav(it) })
            else -> makeSongRows(songs.filter { s ->
                val kwOk = !autoFilterMiApp || lyricKeyword.isBlank() ||
                    s.title.contains(lyricKeyword, true) ||
                    s.artist.contains(lyricKeyword, true) ||
                    s.album.contains(lyricKeyword, true)
                val filterOk = fKind.isEmpty() ||
                    (fKind == "a" && s.artist == fVal) ||
                    (fKind == "b" && s.album == fVal)
                val queryOk = q.isEmpty() ||
                    s.title.contains(q, true) ||
                    s.artist.contains(q, true)
                kwOk && filterOk && queryOk
            })
        }

        listView?.adapter = object : BaseAdapter() {
            override fun getCount() = rows.size
            override fun getItem(position: Int) = rows[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val r = rows[position]
                val itemLayout = (convertView as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(16), dp(6), dp(16), dp(6))
                    addView(
                        ImageView(this@MainActivity).apply {
                            scaleType = ImageView.ScaleType.CENTER_CROP
                            background = rounded(CARD, 8)
                            clipToOutline = true
                            outlineProvider = ViewOutlineProvider.BACKGROUND
                        },
                        LinearLayout.LayoutParams(dp(52), dp(52))
                    )
                    addView(
                        LinearLayout(this@MainActivity).apply {
                            orientation = LinearLayout.VERTICAL
                            setPadding(dp(12), 0, 0, 0)
                            addView(txt("", 15f, Color.WHITE))
                            addView(txt("", 12f, GRAY))
                        },
                        LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                    )
                }

                val img = itemLayout.getChildAt(0) as ImageView
                val textCol = itemLayout.getChildAt(1) as LinearLayout
                val titleView = textCol.getChildAt(0) as TextView
                val subView = textCol.getChildAt(1) as TextView

                titleView.text = r.t
                titleView.setTextColor(if (r.song != null && r.song.id == currentSong?.id) ACCENT else Color.WHITE)
                subView.text = r.s

                img.setImageDrawable(null)
                img.tag = null
                r.song?.let { loadThumbAsync(it, img, 160) }

                itemLayout.setOnClickListener { r.click() }
                itemLayout.setOnLongClickListener {
                    r.long?.invoke()
                    r.long != null
                }
                return itemLayout
            }
        }
    }

    private fun loadThumbAsync(s: Song, iv: ImageView, sizePx: Int) {
        val key = "${s.uri}_$sizePx"
        iv.tag = key
        cache.get(key)?.let {
            iv.setImageBitmap(it)
            return
        }
        if (Build.VERSION.SDK_INT < 29) return
        Thread {
            try {
                val bm = contentResolver.loadThumbnail(s.uri, Size(sizePx, sizePx), null)
                cache.put(key, bm)
                runOnUiThread {
                    if (iv.tag == key) iv.setImageBitmap(bm)
                }
            } catch (_: Exception) {}
        }.start()
    }

    private fun lebLogo(sizeDp: Int = 36): View {
        val size = dp(sizeDp)
        return object : View(this) {
            private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = ACCENT
                style = Paint.Style.FILL
            }
            private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                style = Paint.Style.STROKE
                strokeWidth = dp(2).toFloat()
                alpha = 190
            }
            private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textAlign = Paint.Align.CENTER
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            }

            override fun onDraw(canvas: Canvas) {
                val w = width.toFloat()
                val hPx = height.toFloat()
                val radius = minOf(w, hPx) / 2f
                canvas.drawCircle(w / 2f, hPx / 2f, radius, bgPaint)
                canvas.drawCircle(w / 2f, hPx / 2f, radius - ringPaint.strokeWidth, ringPaint)
                textPaint.textSize = radius * 0.54f
                val y = hPx / 2f - (textPaint.descent() + textPaint.ascent()) / 2f
                canvas.drawText("L.E.B", w / 2f, y, textPaint)
            }
        }.apply {
            layoutParams = LinearLayout.LayoutParams(size, size).apply { rightMargin = dp(10) }
        }
    }

    private fun buildMain(): View {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(34), 0, 0)
        }

        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(8), dp(12), 0)
        }
        topBar.addView(lebLogo(40))

        val titleCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleCol.addView(txt("L.E.B-M", 22f, Color.WHITE, true))
        statusTv = txt(statusMessage, 11f, GRAY).also { titleCol.addView(it) }
        topBar.addView(titleCol, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        topBar.addView(Button(this).apply {
            text = "⚙ Ajustes"
            textSize = 13f
            setTextColor(ACCENT)
            isAllCaps = false
            background = rounded(CARD, 10)
            setPadding(dp(12), dp(6), dp(12), dp(6))
            setOnClickListener { settingsView?.visibility = View.VISIBLE }
        })
        col.addView(topBar)

        val searchBox = EditText(this).apply {
            hint = "Buscar canciones o artistas"
            setHintTextColor(GRAY)
            setTextColor(Color.WHITE)
            setSingleLine(true)
            background = rounded(CARD, 12)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) {
                    query = s?.toString() ?: ""
                    tab = 0
                    refresh()
                }
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            })
        }
        col.addView(
            searchBox,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(dp(16), dp(10), dp(16), dp(4)) }
        )

        val tabBar = LinearLayout(this)
        tabs = listOf("Canciones", "Artistas", "Álbumes", "Favoritas").mapIndexed { idx, name ->
            btn(name, 1f) {
                tab = idx
                fKind = ""
                fVal = ""
                refresh()
            }.apply { textSize = 13f }
        }
        tabs.forEach { tabBar.addView(it) }
        col.addView(tabBar)

        backBtn = btn("‹ Volver") {
            fKind = ""
            fVal = ""
            refresh()
        }.apply {
            setTextColor(ACCENT)
            visibility = View.GONE
        }.also { col.addView(it) }

        listView = ListView(this).apply { divider = null }
        col.addView(listView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        miniBar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(CARD, 14)
            setPadding(dp(8), dp(8), dp(8), dp(8))
            visibility = View.GONE
        }
        miniArt = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = rounded(Color.parseColor("#2A2A35"), 8)
            clipToOutline = true
            outlineProvider = ViewOutlineProvider.BACKGROUND
        }
        miniBar?.addView(miniArt, LinearLayout.LayoutParams(dp(46), dp(46)))

        val miniCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), 0, 0, 0)
        }
        miniTitle = txt("", 15f, Color.WHITE, true).also { miniCol.addView(it) }
        miniSub = txt("", 12f, GRAY).also { miniCol.addView(it) }
        miniBar?.addView(miniCol, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        miniPlayBtn = btn("▶") { togglePlay() }.apply { textSize = 22f }
        miniBar?.addView(miniPlayBtn)
        miniBar?.setOnClickListener {
            fullPlayer?.visibility = View.VISIBLE
            if (animBgEnabled) startBgAnimation()
        }
        col.addView(
            miniBar,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(dp(10), dp(4), dp(10), dp(10)) }
        )

        return col
    }

    private fun buildFull(): View {
        fullPlayer = FrameLayout(this).apply {
            visibility = View.GONE
            isClickable = true
        }

        animBgView = View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(
                    Color.parseColor("#1A1030"),
                    Color.parseColor("#0E0E12"),
                    Color.parseColor("#12182A")
                )
            )
        }
        fullPlayer?.addView(
            animBgView,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(34), dp(22), dp(10))
            setBackgroundColor(Color.TRANSPARENT)
        }

        content.addView(btn("⌄  Cerrar") {
            fullPlayer?.visibility = View.GONE
            stopBgAnimation()
        })

        val logoRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(4), 0, dp(4))
            addView(lebLogo(28))
            addView(txt("L.E.B", 14f, ACCENT, true))
        }
        content.addView(logoRow)

        artView = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = rounded(CARD, 20)
            clipToOutline = true
            outlineProvider = ViewOutlineProvider.BACKGROUND
        }
        content.addView(
            artView,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(220)).apply {
                topMargin = dp(6)
            }
        )

        pTitle = txt("", 22f, Color.WHITE, true).apply { setPadding(0, dp(12), 0, 0) }
        pArtist = txt("", 15f, GRAY)
        content.addView(pTitle)
        content.addView(pArtist)

        seekBar = SeekBar(this).apply {
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser && isPreparedState) {
                        try {
                            mediaPlayer?.seekTo(progress)
                        } catch (_: Exception) {}
                    }
                }
                override fun onStartTrackingTouch(sb: SeekBar?) { isUserSeeking = true }
                override fun onStopTrackingTouch(sb: SeekBar?) { isUserSeeking = false }
            })
        }
        content.addView(seekBar)

        timeTv = txt("0:00 / 0:00", 12f, GRAY).apply { gravity = Gravity.CENTER }
        content.addView(timeTv)

        val ctl = LinearLayout(this).apply { gravity = Gravity.CENTER }
        pShufBtn = btn("🔀", 1f) {
            shuffleEnabled = !shuffleEnabled
            syncUi()
        }
        pRepBtn = btn("🔁", 1f) {
            repeatMode = (repeatMode + 1) % 3
            syncUi()
        }
        pPlayBtn = btn("▶", 1.3f) { togglePlay() }.apply {
            textSize = 32f
            setTextColor(ACCENT)
        }
        ctl.addView(pShufBtn)
        ctl.addView(btn("⏮", 1f) { skipPrev() }.apply { textSize = 24f })
        ctl.addView(pPlayBtn)
        ctl.addView(btn("⏭", 1f) { skipNext() }.apply { textSize = 24f })
        ctl.addView(pRepBtn)
        content.addView(ctl)

        speedTv = txt("Velocidad: %.2fx".format(rate), 13f, Color.WHITE).apply { gravity = Gravity.CENTER }
        content.addView(speedTv)

        val speedRow = LinearLayout(this)
        speedRow.addView(btn("🐢 Slowed", 1f) { setRate(0.8f) })
        speedRow.addView(btn("Normal", 1f) { setRate(1.0f) })
        speedRow.addView(btn("🐇 Sped up", 1f) { setRate(1.25f) })
        content.addView(speedRow)

        val extraRow = LinearLayout(this).apply { gravity = Gravity.CENTER }
        favBtn = btn("♡", 1f) { toggleFav(currentSong) }.apply { textSize = 24f }
        sleepBtn = btn("⏲ Dormir", 1f) { showSleepDialog() }
        extraRow.addView(favBtn)
        extraRow.addView(sleepBtn)
        extraRow.addView(btn("Tono", 1f) {
            keepPitch = !keepPitch
            applyPlaybackSpeed()
            showToast(if (keepPitch) "Tono original" else "Tono dinámico con velocidad")
        })
        content.addView(extraRow)

        lyricsPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.parseColor("#1A1A28"), 14)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            visibility = if (showLyrics) View.VISIBLE else View.GONE
        }

        val lHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        lHeader.addView(txt("Letra dinámica", 12f, ACCENT, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        lHeader.addView(Button(this).apply {
            text = "Editar"
            textSize = 11f
            setTextColor(Color.WHITE)
            isAllCaps = false
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener { currentSong?.let { showLyricEditor(it) } }
        })
        lyricsPanel?.addView(lHeader)

        lyricsScroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false }
        lyricsTv = TextView(this).apply {
            text = "Sin letra cargada para esta canción."
            textSize = lyricSize
            setTextColor(LYRIC_INACTIVE)
            setLineSpacing(dp(6).toFloat(), 1.2f)
            setPadding(0, dp(4), 0, dp(8))
        }
        lyricsScroll?.addView(lyricsTv)
        lyricsPanel?.addView(
            lyricsScroll,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f).apply { topMargin = dp(4) }
        )
        content.addView(
            lyricsPanel,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f).apply { topMargin = dp(8) }
        )

        fullPlayer?.addView(
            content,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        return fullPlayer!!
    }

    private fun startBgAnimation() {
        if (!animBgEnabled) {
            animBgView?.setBackgroundColor(BG)
            return
        }
        stopBgAnimation()
        val palette = arrayOf(
            intArrayOf(Color.parseColor("#1A1030"), Color.parseColor("#0E0E12"), Color.parseColor("#12182A")),
            intArrayOf(Color.parseColor("#20103A"), Color.parseColor("#120E1A"), Color.parseColor("#0E1A2A")),
            intArrayOf(Color.parseColor("#181428"), Color.parseColor("#0A0A14"), Color.parseColor("#141A28")),
            intArrayOf(Color.parseColor("#221038"), Color.parseColor("#0E0C18"), Color.parseColor("#101828"))
        )
        var idx = 0
        bgAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 4500L
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { anim ->
                val t = anim.animatedFraction
                val from = palette[idx % palette.size]
                val to = palette[(idx + 1) % palette.size]
                val eval = ArgbEvaluator()
                val c1 = eval.evaluate(t, from[0], to[0]) as Int
                val c2 = eval.evaluate(t, from[1], to[1]) as Int
                val c3 = eval.evaluate(t, from[2], to[2]) as Int
                animBgView?.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(c1, c2, c3))
            }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationRepeat(animation: android.animation.Animator) {
                    idx = (idx + 1) % palette.size
                }
            })
            start()
        }
    }

    private fun stopBgAnimation() {
        bgAnimator?.cancel()
        bgAnimator = null
    }

    private fun lyricKey(s: Song?) = if (s == null) "" else "leb_lyric_${s.id}"

    private fun parseLrc(raw: String): List<LyricLine> {
        val result = ArrayList<LyricLine>()
        val regex = Regex("\\[(\\d{1,2}):(\\d{2})(?:\\.(\\d{1,3}))?\\]\\s*(.*)")
        for (line in raw.lines()) {
            val match = regex.find(line.trim())
            if (match != null) {
                val min = match.groupValues[1].toLongOrNull() ?: 0L
                val sec = match.groupValues[2].toLongOrNull() ?: 0L
                val msPart = match.groupValues[3]
                val ms = when {
                    msPart.isEmpty() -> 0L
                    msPart.length == 1 -> msPart.toLong() * 100L
                    msPart.length == 2 -> msPart.toLong() * 10L
                    else -> msPart.take(3).toLongOrNull() ?: 0L
                }
                val text = match.groupValues[4].trim()
                if (text.isNotEmpty()) {
                    result.add(LyricLine(min * 60000L + sec * 1000L + ms, text))
                }
            }
        }
        return result.sortedBy { it.timeMs }
    }

    private fun loadLyrics(s: Song?): Pair<String, List<LyricLine>> {
        if (s == null) return "Reproducí una canción para ver su letra." to emptyList()

        val custom = prefs.getString(lyricKey(s), null)
        if (!custom.isNullOrBlank()) {
            val parsed = parseLrc(custom)
            return if (parsed.isNotEmpty()) custom to parsed
            else custom to custom.lines().filter { it.isNotBlank() }.map { LyricLine(0L, it) }
        }

        val dirs = listOfNotNull(
            getExternalFilesDir(null),
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC),
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        )
        val cleanName = s.title.replace(Regex("[\\\\/:*?\"<>|]"), "").trim()
        for (dir in dirs) {
            if (!dir.exists()) continue
            val candidates = listOf(
                File(dir, "$cleanName.lrc"),
                File(dir, "$cleanName.txt"),
                File(File(dir, lyricKeyword), "$cleanName.lrc"),
                File(File(dir, lyricKeyword), "$cleanName.txt")
            )
            val found = candidates.firstOrNull { it.exists() && it.canRead() }
            if (found != null) {
                val raw = found.readText()
                val parsed = parseLrc(raw)
                return if (parsed.isNotEmpty()) raw to parsed
                else {
                    val plain = raw.lines().joinToString("\n") {
                        it.replace(Regex("^\\[[0-9:.]+\\]\\s*"), "")
                    }.trim()
                    plain to plain.lines().filter { it.isNotBlank() }.map { LyricLine(0L, it) }
                }
            }
        }

        return "Sin letra para \"${s.title}\".\nTocá \"Editar\" para agregarla o colocá un archivo .lrc" to emptyList()
    }

    private fun refreshLyrics(s: Song?) {
        val panel = lyricsPanel ?: return
        val tv = lyricsTv ?: return
        panel.visibility = if (showLyrics) View.VISIBLE else View.GONE
        tv.textSize = lyricSize

        val (display, lines) = loadLyrics(s)
        lyricLines = lines
        currentLyricIndex = -1

        if (lines.isEmpty() || lines.all { it.timeMs == 0L }) {
            tv.text = display
            tv.setTextColor(Color.WHITE)
        } else {
            updateLyricHighlight(-1)
        }
    }

    private fun updateLyricHighlight(index: Int) {
        val tv = lyricsTv ?: return
        if (lyricLines.isEmpty()) return
        currentLyricIndex = index

        val sb = SpannableStringBuilder()
        lyricLines.forEachIndexed { idx, line ->
            if (idx > 0) sb.append("\n")
            val start = sb.length
            sb.append(line.text)
            val end = sb.length
            if (idx == index) {
                sb.setSpan(ForegroundColorSpan(LYRIC_ACTIVE), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                sb.setSpan(StyleSpan(Typeface.BOLD), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                sb.setSpan(RelativeSizeSpan(1.18f), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            } else {
                val dim = if (index >= 0 && abs(idx - index) <= 1) Color.parseColor("#9A90B8") else LYRIC_INACTIVE
                sb.setSpan(ForegroundColorSpan(dim), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
        }
        tv.text = sb

        val scroll = lyricsScroll
        if (index >= 0 && scroll != null) {
            tv.post {
                try {
                    val layout = tv.layout ?: return@post
                    if (index >= layout.lineCount) return@post
                    val y = layout.getLineTop(index)
                    val offset = scroll.height / 3
                    scroll.smoothScrollTo(0, (y - offset).coerceAtLeast(0))
                } catch (_: Exception) {}
            }
        }
    }

    private fun showLyricEditor(s: Song) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(12), dp(18), dp(6))
        }
        val input = EditText(this).apply {
            setText(prefs.getString(lyricKey(s), "") ?: "")
            hint = "Pegá la letra (soporta formato LRC con [mm:ss.xx])"
            minLines = 8
            gravity = Gravity.TOP or Gravity.START
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            setTextColor(Color.WHITE)
            setHintTextColor(GRAY)
        }
        box.addView(input)
        AlertDialog.Builder(this)
            .setTitle("Letra · ${s.title}")
            .setView(box)
            .setPositiveButton("Guardar") { _, _ ->
                prefs.edit().putString(lyricKey(s), input.text.toString().trim()).apply()
                refreshLyrics(s)
                showToast("Letra guardada")
            }
            .setNeutralButton("Borrar") { _, _ ->
                prefs.edit().remove(lyricKey(s)).apply()
                refreshLyrics(s)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun buildSettings(): View {
        settingsView = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
            setPadding(dp(20), dp(34), dp(20), dp(16))
            visibility = View.GONE
            isClickable = true
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        top.addView(btn("‹ Volver") { settingsView?.visibility = View.GONE }.apply { setTextColor(ACCENT) })
        top.addView(txt("Ajustes · v2.2", 22f, Color.WHITE, true).apply { setPadding(dp(8), 0, 0, 0) })
        settingsView?.addView(top)

        val scroll = ScrollView(this)
        val inner = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(14), 0, dp(24))
        }

        inner.addView(txt("LETRAS", 13f, ACCENT, true).apply { bottomMargin = dp(10) })

        val swLyrics = Switch(this).apply {
            text = "Mostrar letras en reproductor"
            setTextColor(Color.WHITE)
            isChecked = showLyrics
        }
        inner.addView(swLyrics, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(10) })

        val swFilter = Switch(this).apply {
            text = "Filtrar biblioteca con palabra clave"
            setTextColor(Color.WHITE)
            isChecked = autoFilterMiApp
        }
        inner.addView(swFilter, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(10) })

        inner.addView(txt("Palabra clave / carpeta de letras:", 13f, GRAY).apply { bottomMargin = dp(4) })

        val kwInput = EditText(this).apply {
            setText(lyricKeyword)
            setTextColor(Color.WHITE)
            background = rounded(CARD, 10)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setSingleLine(true)
        }
        inner.addView(kwInput, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(14) })

        val sizeLabel = txt("Tamaño de letra: ${lyricSize.toInt()}sp", 13f, Color.WHITE).apply { bottomMargin = dp(4) }
        inner.addView(sizeLabel)

        val seekSize = SeekBar(this).apply {
            max = 28
            progress = (lyricSize.toInt() - 10).coerceIn(0, 28)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                    sizeLabel.text = "Tamaño de letra: ${progress + 10}sp"
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        inner.addView(seekSize, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(18) })

        inner.addView(txt("VISUAL", 13f, ACCENT, true).apply { bottomMargin = dp(10) })

        val swAnim = Switch(this).apply {
            text = "Fondos animados en reproductor"
            setTextColor(Color.WHITE)
            isChecked = animBgEnabled
        }
        inner.addView(swAnim, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(20) })

        inner.addView(Button(this).apply {
            text = "Guardar ajustes"
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = rounded(ACCENT, 12)
            setPadding(0, dp(14), 0, dp(14))
            setOnClickListener {
                showLyrics = swLyrics.isChecked
                autoFilterMiApp = swFilter.isChecked
                lyricKeyword = kwInput.text.toString().trim().ifEmpty { "miapp" }
                lyricSize = (seekSize.progress + 10).toFloat()
                animBgEnabled = swAnim.isChecked

                prefs.edit()
                    .putBoolean("leb_show_lyrics", showLyrics)
                    .putBoolean("leb_auto_filter", autoFilterMiApp)
                    .putString("leb_keyword", lyricKeyword)
                    .putInt("leb_lyric_size", lyricSize.toInt())
                    .putBoolean("leb_anim_bg", animBgEnabled)
                    .apply()

                refreshLyrics(currentSong)
                refresh()
                if (fullPlayer?.visibility == View.VISIBLE) {
                    if (animBgEnabled) startBgAnimation() else stopBgAnimation()
                }
                settingsView?.visibility = View.GONE
                showToast("Ajustes guardados")
            }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(12) })

        inner.addView(Button(this).apply {
            text = "Volver a escanear música"
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = rounded(CARD, 12)
            setPadding(0, dp(14), 0, dp(14))
            setOnClickListener {
                if (hasAudioPerm()) {
                    scanSongsSafe()
                } else {
                    try {
                        requestPermissions(requiredPermissions(), 101)
                    } catch (_: Exception) {}
                }
            }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(12) })

        inner.addView(Button(this).apply {
            text = "Abrir permisos de la app en Android"
            isAllCaps = false
            setTextColor(ACCENT)
            background = rounded(CARD, 12)
            setPadding(0, dp(14), 0, dp(14))
            setOnClickListener {
                try {
                    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                        data = Uri.fromParts("package", packageName, null)
                    }
                    startActivity(intent)
                } catch (_: Exception) {
                    showToast("Abrí Ajustes del teléfono → Aplicaciones → L.E.B-M")
                }
            }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        scroll.addView(inner)
        settingsView?.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        return settingsView!!
    }

    private fun showSleepDialog() {
        val options = arrayOf("15 minutos", "30 minutos", "45 minutos", "1 hora", "Cancelar temporizador")
        val mins = intArrayOf(15, 30, 45, 60, 0)
        AlertDialog.Builder(this)
            .setTitle("Temporizador para dormir")
            .setItems(options) { _, which ->
                sleepAt = if (mins[which] == 0) 0L else System.currentTimeMillis() + mins[which] * 60000L
                if (mins[which] == 0) sleepBtn?.text = "⏲ Dormir"
            }.show()
    }

    private fun syncUi() {
        statusTv?.text = statusMessage
        val song = currentSong
        miniBar?.visibility = if (song != null) View.VISIBLE else View.GONE

        if (song != null) {
            pTitle?.text = song.title
            pArtist?.text = song.artist
            miniTitle?.text = song.title
            miniSub?.text = song.artist
            artView?.let { loadThumbAsync(song, it, 600) }
            miniArt?.let { loadThumbAsync(song, it, 160) }
            refreshLyrics(song)
        } else {
            refreshLyrics(null)
        }

        val icon = if (isPlayingState) "⏸" else "▶"
        pPlayBtn?.text = icon
        miniPlayBtn?.text = icon
        pShufBtn?.alpha = if (shuffleEnabled) 1.0f else 0.4f
        pRepBtn?.alpha = if (repeatMode != 0) 1.0f else 0.4f
        pRepBtn?.text = if (repeatMode == 2) "🔂" else "🔁"
        favBtn?.text = if (isFav(song)) "♥" else "♡"
        listView?.invalidateViews()
    }

    private fun fmt(ms: Long): String {
        val safe = ms.coerceAtLeast(0L)
        return "%d:%02d".format(safe / 60000L, (safe / 1000L) % 60L)
    }

    private fun startTickLoop() {
        h.postDelayed(object : Runnable {
            override fun run() {
                try {
                    val mp = mediaPlayer
                    if (mp != null && isPreparedState) {
                        val dur = try { mp.duration } catch (_: Exception) { 0 }
                        val pos = try { mp.currentPosition } catch (_: Exception) { 0 }
                        if (dur > 0 && !isUserSeeking) {
                            seekBar?.max = dur
                            seekBar?.progress = pos.coerceIn(0, dur)
                            timeTv?.text = "${fmt(pos.toLong())} / ${fmt(dur.toLong())}"
                        }
                        if (showLyrics && lyricLines.isNotEmpty() && lyricLines.any { it.timeMs > 0L }) {
                            var idx = -1
                            for (i in lyricLines.indices) {
                                if (lyricLines[i].timeMs <= pos) idx = i else break
                            }
                            if (idx != currentLyricIndex) {
                                updateLyricHighlight(idx)
                            }
                        }
                    }

                    if (sleepAt > 0L) {
                        val left = sleepAt - System.currentTimeMillis()
                        if (left <= 0L) {
                            sleepAt = 0L
                            try {
                                if (mediaPlayer?.isPlaying == true) mediaPlayer?.pause()
                            } catch (_: Exception) {}
                            isPlayingState = false
                            sleepBtn?.text = "⏲ Dormir"
                            syncUi()
                        } else {
                            sleepBtn?.text = "⏲ ${left / 60000L + 1L} min"
                        }
                    }
                } catch (_: Exception) {}
                h.postDelayed(this, 450L)
            }
        }, 450L)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            settingsView?.visibility == View.VISIBLE -> settingsView?.visibility = View.GONE
            fullPlayer?.visibility == View.VISIBLE -> {
                fullPlayer?.visibility = View.GONE
                stopBgAnimation()
            }
            fKind.isNotEmpty() -> {
                fKind = ""
                fVal = ""
                refresh()
            }
            else -> super.onBackPressed()
        }
    }

    override fun onDestroy() {
        stopBgAnimation()
        h.removeCallbacksAndMessages(null)
        try {
            mediaPlayer?.release()
        } catch (_: Exception) {}
        mediaPlayer = null
        super.onDestroy()
    }
}
