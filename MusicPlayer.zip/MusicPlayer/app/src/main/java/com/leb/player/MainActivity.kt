package com.leb.player

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.provider.MediaStore.Audio.Media as AM
import android.text.Editable
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.TextWatcher
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.text.style.StyleSpan
import android.util.Log
import android.util.LruCache
import android.util.Size
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.*
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import java.util.concurrent.Executor

class MainActivity : Activity() {
    data class Song(val id: Long, val title: String, val artist: String, val album: String, val albumId: Long, val uri: Uri)
    data class Row(val t: String, val s: String, val song: Song? = null, val long: (() -> Unit)? = null, val click: () -> Unit)

    private val GREEN = Color.parseColor("#1ED760")
    private val GRAY = Color.parseColor("#B3B3C0")
    private val ACCENT = Color.parseColor("#8B6CFF")
    private val PINK = Color.parseColor("#FF4F9A")
    private val CARD_BG = Color.parseColor("#1A1A28")
    private val h = Handler(Looper.getMainLooper())
    private val songs = ArrayList<Song>()
    private val cache = LruCache<String, Bitmap>(60)
    private val logos = HashMap<Int, Bitmap>()
    private val prefs by lazy { getSharedPreferences("leb", MODE_PRIVATE) }
    private var ctrl: MediaController? = null
    private var page = 0
    private var libSub = 0
    private var scope = 0
    private var fKind = ""
    private var fVal = ""
    private var query = ""
    private var rows: List<Row> = emptyList()
    private var keepPitch = false
    private var rate = 1f
    private var sleepAt = 0L
    private var homeHeader: View? = null
    private var introLayer: View? = null
    private var netTick = 0
    private val translators = HashMap<String, Translator>()
    private lateinit var offlineBar: TextView
    private var tint = Color.parseColor("#4A36B0")
    private var logoTaps = 0
    private var logoTapAt = 0L

    private var lyLines: List<Lyrics.Line> = emptyList()
    private var lySynced = false
    private var lyRaw: String? = null
    private var lyTrans: Array<String?> = arrayOfNulls(0)
    private var lyShowTrans = false
    private var lyActive = -1
    private var lySong = -1L
    private var lyStatus = ""

    private lateinit var bg: ImageView
    private lateinit var controls: LinearLayout
    private lateinit var searchBox: EditText
    private lateinit var list: ListView
    private lateinit var navBtns: List<Button>
    private lateinit var mini: LinearLayout
    private lateinit var miniArt: ImageView
    private lateinit var miniT: TextView
    private lateinit var miniS: TextView
    private lateinit var miniPlay: Button
    private lateinit var miniProg: ProgressBar
    private lateinit var full: LinearLayout
    private lateinit var art: ImageView
    private lateinit var pT: TextView
    private lateinit var pS: TextView
    private lateinit var seek: SeekBar
    private lateinit var timeTv: TextView
    private lateinit var pPlay: Button
    private lateinit var pShuf: Button
    private lateinit var pRep: Button
    private lateinit var favBtn: Button
    private lateinit var sleepBtn: Button
    private lateinit var bottomLyrics: TextView
    private lateinit var bottomLyricsScroll: ScrollView
    private lateinit var settings: ScrollView
    private lateinit var setCol: LinearLayout

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun rounded(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }
    private fun cardBg(c: Int = CARD_BG, r: Int = 16) = GradientDrawable().apply {
        setColor(c); cornerRadius = dp(r).toFloat()
        setStroke(dp(1), Color.parseColor("#33FFFFFF"))
    }
    private fun txt(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }
    private fun btn(t: String, w: Float = 0f, f: () -> Unit) = Button(this).apply {
        text = t; setTextColor(Color.WHITE); isAllCaps = false; setBackgroundColor(Color.TRANSPARENT)
        layoutParams = LinearLayout.LayoutParams(if (w > 0) 0 else -2, -2, w); setOnClickListener { f() }
    }
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private fun showLyricsOn() = prefs.getBoolean("ly_show", true)
    private fun lyricSize() = prefs.getInt("ly_size", 16)
    private fun keyword() = prefs.getString("ly_kw", "") ?: ""
    private fun treeUri(): Uri? = prefs.getString("ly_tree", null)?.let { Uri.parse(it) }
    private fun isPro() = prefs.getBoolean("pro", false) || prefs.getBoolean("dev_force_pro", false)
    private fun isDev() = prefs.getBoolean("dev_mode", false)
    private fun unlockDev() {
        prefs.edit().putBoolean("dev_mode", true).apply()
        toast("Modo desarrollador activado")
        fillSettings()
    }
    private fun onLogoTap() {
        val now = System.currentTimeMillis()
        if (now - logoTapAt > 2000L) logoTaps = 0
        logoTapAt = now
        logoTaps++
        if (logoTaps >= 7) {
            logoTaps = 0
            if (isDev()) {
                toast("Modo desarrollador ya activo")
                openSettings()
            } else {
                val e = EditText(this).apply {
                    hint = "PIN de desarrollador"
                    inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
                    setTextColor(Color.WHITE)
                    setHintTextColor(GRAY)
                    setBackgroundColor(Color.parseColor("#333333"))
                    setPadding(dp(16), dp(12), dp(16), dp(12))
                }
                AlertDialog.Builder(this)
                    .setTitle("L.E.B Developer")
                    .setMessage("Ingresá el PIN para opciones de desarrollador (beta).")
                    .setView(e)
                    .setPositiveButton("Entrar") { _, _ ->
                        if (e.text.toString().trim() == "lebdev") unlockDev()
                        else toast("PIN incorrecto")
                    }
                    .setNegativeButton("Cancelar", null)
                    .show()
            }
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { prefs.edit().putString("crash", Log.getStackTraceString(e).take(1800)).commit() } catch (_: Exception) {}
            old?.uncaughtException(t, e)
        }
        keepPitch = prefs.getBoolean("pitch", false)
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        bg = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        root.addView(bg)
        root.addView(View(this).apply { setBackgroundColor(Color.parseColor("#99000000")) })
        root.addView(buildMain())
        root.addView(buildFull())
        root.addView(buildSettings())
        root.addView(buildIntro())
        setContentView(root)
        loadBackground()
        refresh()
        val perms = if (Build.VERSION.SDK_INT >= 33)
            arrayOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
        else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        if (hasAudioPerm()) scan()
        if (perms.any { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }) requestPermissions(perms, 1)
        connect()
        tick()
        prefs.getString("crash", null)?.let { c ->
            prefs.edit().remove("crash").apply()
            h.postDelayed({
                try { AlertDialog.Builder(this).setTitle("La app se cerró la última vez").setMessage(c).setPositiveButton("Cerrar", null).show() } catch (_: Exception) {}
            }, 2500)
        }
    }

    private fun hasAudioPerm() = checkSelfPermission(
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
    ) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        if (hasAudioPerm()) scan() else toast("Necesito permiso para ver tu música")
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val u = data?.data ?: return
        if (res != RESULT_OK) return
        try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
        if (req == 7) { prefs.edit().putString("ly_tree", u.toString()).apply(); lySong = -1L; fillSettings(); syncUi() }
        if (req == 9) { prefs.edit().putString("intro_video", u.toString()).apply(); toast("Video guardado"); fillSettings() }
        if (req == 8) { prefs.edit().putString("bg", u.toString()).apply(); loadBackground() }
    }

    override fun onBackPressed() {
        when {
            introLayer?.visibility == View.VISIBLE -> introLayer?.let { endIntro(it) }
            settings.visibility == View.VISIBLE -> settings.visibility = View.GONE
            full.visibility == View.VISIBLE -> full.visibility = View.GONE
            fKind.isNotEmpty() -> { fKind = ""; refresh() }
            else -> super.onBackPressed()
        }
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        try { ctrl?.release() } catch (_: Exception) {}
        translators.values.forEach { try { it.close() } catch (_: Throwable) {} }
        super.onDestroy()
    }

    private fun spaceBitmap(): Bitmap {
        val w = 540; val hh = 960
        val bm = Bitmap.createBitmap(w, hh, Bitmap.Config.ARGB_8888)
        val c = Canvas(bm); val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(0f, 0f, 0f, hh.toFloat(), Color.parseColor("#02010A"), Color.parseColor("#1A0B3D"), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w.toFloat(), hh.toFloat(), p)
        val r = java.util.Random(7)
        fun blob(x: Float, y: Float, rad: Float, col: Int) {
            p.shader = RadialGradient(x, y, rad, col, Color.TRANSPARENT, Shader.TileMode.CLAMP)
            c.drawCircle(x, y, rad, p)
        }
        blob(120f, 260f, 330f, Color.parseColor("#553A1FA8"))
        blob(430f, 520f, 380f, Color.parseColor("#44B02F8F"))
        p.shader = null
        for (i in 0 until 200) {
            p.color = Color.argb(60 + r.nextInt(190), 255, 255, 255)
            c.drawCircle(r.nextFloat() * w, r.nextFloat() * hh, 0.5f + r.nextFloat() * 1.6f, p)
        }
        return bm
    }

    private fun loadBackground() {
        Thread {
            var bm: Bitmap? = null
            try {
                prefs.getString("bg", null)?.let { u ->
                    val o = BitmapFactory.Options().apply { inSampleSize = 4 }
                    contentResolver.openInputStream(Uri.parse(u))?.use { bm = BitmapFactory.decodeStream(it, null, o) }
                }
            } catch (_: Exception) {}
            val res = bm ?: spaceBitmap()
            runOnUiThread { bg.setImageBitmap(res) }
        }.start()
    }

    private fun emblem(size: Int): Bitmap = logos.getOrPut(size) {
        val bm = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bm); val p = Paint(Paint.ANTI_ALIAS_FLAG); val s = size.toFloat()
        p.shader = LinearGradient(0f, 0f, s, s, Color.parseColor("#6D4BFF"), Color.parseColor("#1B1245"), Shader.TileMode.CLAMP)
        c.drawRoundRect(0f, 0f, s, s, s * 0.22f, s * 0.22f, p)
        p.shader = null; p.style = Paint.Style.STROKE; p.strokeWidth = s * 0.035f; p.color = Color.parseColor("#B9A8FF")
        c.drawCircle(s / 2, s / 2, s * 0.36f, p)
        p.style = Paint.Style.FILL; p.color = Color.WHITE; p.textAlign = Paint.Align.CENTER; p.isFakeBoldText = true; p.textSize = s * 0.17f
        c.drawText("L.E.B-M", s / 2, s * 0.52f, p)
        p.isFakeBoldText = false; p.color = Color.parseColor("#D9CFFF"); p.textSize = s * 0.085f
        c.drawText("computing", s / 2, s * 0.66f, p)
        bm
    }

    private fun art(s: Song) = ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), s.albumId)

    private fun thumb(s: Song, iv: ImageView, size: Int, done: ((Bitmap) -> Unit)? = null) {
        val key = s.uri.toString() + size; iv.tag = key
        cache.get(key)?.let { iv.setImageBitmap(it); done?.invoke(it); return }
        iv.setImageBitmap(emblem(size)); done?.invoke(emblem(size))
        if (Build.VERSION.SDK_INT < 29) return
        Thread {
            try {
                val bm = contentResolver.loadThumbnail(s.uri, Size(size, size), null)
                cache.put(key, bm)
                runOnUiThread { if (iv.tag == key) { iv.setImageBitmap(bm); done?.invoke(bm) } }
            } catch (_: Exception) {}
        }.start()
    }

    private fun applyTint(bm: Bitmap) {
        try {
            val px = Bitmap.createScaledBitmap(bm, 1, 1, true).getPixel(0, 0)
            val hsv = FloatArray(3); Color.colorToHSV(px, hsv)
            hsv[1] = minOf(1f, hsv[1] + 0.15f); hsv[2] = minOf(hsv[2], 0.55f).coerceAtLeast(0.30f)
            tint = Color.HSVToColor(hsv)
            full.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(tint, Color.parseColor("#0B0B12")))
        } catch (_: Exception) {}
    }

    private fun roundImg(r: Int = 8) = ImageView(this).apply {
        scaleType = ImageView.ScaleType.CENTER_CROP
        background = rounded(Color.parseColor("#2A2A35"), r)
        clipToOutline = true; outlineProvider = ViewOutlineProvider.BACKGROUND
    }

    private val listener = object : Player.Listener {
        override fun onMediaItemTransition(m: MediaItem?, r: Int) { syncUi() }
        override fun onIsPlayingChanged(p: Boolean) { syncUi() }
        override fun onPlaybackStateChanged(s: Int) { syncUi() }
        override fun onPlayerError(e: PlaybackException) {
            toast("No se pudo reproducir esta canción")
            try { ctrl?.let { if (it.hasNextMediaItem()) { it.seekToNext(); it.prepare(); it.play() } } } catch (_: Exception) {}
        }
    }

    private fun connect() {
        try {
            val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
            val f = MediaController.Builder(this, token).buildAsync()
            f.addListener({
                try { ctrl = f.get(); ctrl?.addListener(listener); syncUi() } catch (_: Exception) { toast("No se pudo iniciar el reproductor") }
            }, Executor { h.post(it) })
        } catch (_: Exception) { toast("No se pudo iniciar el reproductor") }
    }

    private fun item(s: Song) = MediaItem.Builder().setMediaId(s.id.toString()).setUri(s.uri)
        .setMediaMetadata(MediaMetadata.Builder().setTitle(s.title).setArtist(s.artist).setAlbumTitle(s.album).setArtworkUri(art(s)).build()).build()

    private fun playList(l: List<Song>, i: Int) {
        val c = ctrl ?: run { toast("Conectando…"); return }
        try {
            c.setMediaItems(l.map { item(it) }, i, 0L); c.prepare(); c.play(); applySpeed()
            full.visibility = View.VISIBLE
        } catch (_: Exception) { toast("No se pudo reproducir") }
    }

    private fun shuffleAll() {
        if (songs.isEmpty()) { toast("No hay música"); return }
        ctrl?.shuffleModeEnabled = true
        playList(songs, (Math.random() * songs.size).toInt())
    }

    private fun current(): Song? = ctrl?.currentMediaItem?.mediaId?.let { id -> songs.find { it.id.toString() == id } }
    private fun applySpeed() { try { ctrl?.setPlaybackParameters(PlaybackParameters(rate, if (keepPitch) 1f else rate)) } catch (_: Exception) {} }
    private fun setRate(r: Float) { rate = r; applySpeed() }
    private fun togglePlay() { ctrl?.let { if (it.isPlaying) it.pause() else it.play() } }

    private fun scan() {
        Thread {
            val out = ArrayList<Song>()
            try {
                val base = AM.EXTERNAL_CONTENT_URI
                val shortSel = if (prefs.getBoolean("short", false)) "" else "AND ${AM.DURATION}>=30000 "
                contentResolver.query(
                    base, arrayOf(AM._ID, AM.TITLE, AM.ARTIST, AM.ALBUM, AM.ALBUM_ID),
                    "${AM.IS_MUSIC}!=0 ${shortSel}AND ${AM.DATA} NOT LIKE '%WhatsApp%'", null, "${AM.TITLE} COLLATE NOCASE ASC"
                )?.use { c ->
                    while (c.moveToNext()) {
                        val artist = c.getString(2)?.takeIf { it != "<unknown>" } ?: "Artista desconocido"
                        out.add(Song(c.getLong(0), c.getString(1) ?: "Sin título", artist, c.getString(3) ?: "Álbum desconocido", c.getLong(4), ContentUris.withAppendedId(base, c.getLong(0))))
                    }
                }
            } catch (_: Exception) {}
            runOnUiThread {
                songs.clear(); songs.addAll(out); refresh()
                if (out.isEmpty()) toast("No encontré música") else toast("${out.size} canciones")
            }
        }.start()
    }

    private fun favs(): MutableSet<String> = HashSet(prefs.getStringSet("fav", emptySet()) ?: emptySet())
    private fun isFav(s: Song?) = s != null && favs().contains(s.id.toString())
    private fun toggleFav(s: Song?) {
        if (s == null) return
        val set = favs()
        if (!set.remove(s.id.toString())) set.add(s.id.toString())
        prefs.edit().putStringSet("fav", set).apply()
        syncUi(); rebuildRows()
    }

    private fun songRows(l: List<Song>) = l.mapIndexed { i, s -> Row(s.title, s.artist + if (isFav(s)) "  ♥" else "", s, { toggleFav(s) }) { playList(l, i) } }
    private fun groupRows(by: (Song) -> String, kind: String, q: String): List<Row> =
        songs.groupBy(by).filter { q.isEmpty() || it.key.contains(q, true) }.map { (k, v) -> Row(k, "${v.size} canciones", v.first()) { fKind = kind; fVal = k; refresh() } }

    private fun refresh() {
        buildControls(); rebuildRows()
        navBtns.forEachIndexed { i, b -> b.setTextColor(if (i == page) GREEN else GRAY) }
    }

    private fun chip(t: String, sel: Boolean, f: () -> Unit) = TextView(this).apply {
        text = t; textSize = 13f; setPadding(dp(14), dp(7), dp(14), dp(7))
        background = rounded(if (sel) Color.WHITE else Color.parseColor("#44FFFFFF"), 20)
        setTextColor(if (sel) Color.BLACK else Color.WHITE)
        setOnClickListener { f() }
        layoutParams = LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }
    }

    private fun chipRow(names: List<String>, cur: Int, f: (Int) -> Unit) = LinearLayout(this).apply {
        setPadding(dp(12), 0, dp(12), 0)
        names.forEachIndexed { i, n -> addView(chip(n, i == cur) { f(i) }) }
    }

    private fun buildControls() {
        controls.removeAllViews()
        if (fKind.isNotEmpty()) {
            controls.addView(btn("‹ Volver   ·   $fVal") { fKind = ""; refresh() }.apply { setTextColor(GREEN) })
            return
        }
        when (page) {
            0 -> {}
            1 -> {
                controls.addView(searchBox)
                controls.addView(chipRow(listOf("Canciones", "Artistas", "Álbumes"), scope) { scope = it; refresh() })
            }
            else -> controls.addView(chipRow(listOf("Artistas", "Álbumes", "Favoritas"), libSub) { libSub = it; refresh() })
        }
    }

    private fun rebuildRows() {
        val q = query.trim()
        rows = when {
            fKind.isNotEmpty() -> songRows(songs.filter { if (fKind == "a") it.artist == fVal else it.album == fVal })
            page == 0 -> songRows(songs)
            page == 1 -> when {
                q.isEmpty() -> listOf(Row("Busca canciones, artistas o álbumes", "") {})
                scope == 1 -> onlineRows(q) + groupRows({ it.artist }, "a", q)
                scope == 2 -> onlineRows(q) + groupRows({ it.album }, "b", q)
                else -> onlineRows(q) + songRows(songs.filter { it.title.contains(q, true) || it.artist.contains(q, true) || it.album.contains(q, true) })
            }
            else -> when (libSub) {
                0 -> groupRows({ it.artist }, "a", "")
                1 -> groupRows({ it.album }, "b", "")
                else -> songRows(songs.filter { isFav(it) })
            }
        }
        try { homeHeader?.let { list.removeHeaderView(it) } } catch (_: Exception) {}
        homeHeader = null
        if (page == 0 && fKind.isEmpty()) {
            val hv = buildHome(); homeHeader = hv; list.addHeaderView(hv, null, false)
        }
        list.adapter = object : BaseAdapter() {
            override fun getCount() = rows.size
            override fun getItem(p: Int) = rows[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun getView(p: Int, v: View?, g: ViewGroup): View {
                val r = rows[p]
                val view = (v as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                    gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16), dp(6), dp(16), dp(6))
                    addView(roundImg(), LinearLayout.LayoutParams(dp(52), dp(52)))
                    addView(LinearLayout(this@MainActivity).apply {
                        orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0)
                        addView(txt("", 15f, Color.WHITE).apply { setSingleLine(true) })
                        addView(txt("", 12f, GRAY).apply { setSingleLine(true) })
                    }, LinearLayout.LayoutParams(0, -2, 1f))
                }
                val img = view.getChildAt(0) as ImageView
                val col = view.getChildAt(1) as LinearLayout
                (col.getChildAt(0) as TextView).apply {
                    text = r.t
                    setTextColor(if (r.song != null && r.song.id == current()?.id && r.long != null) GREEN else Color.WHITE)
                }
                (col.getChildAt(1) as TextView).text = r.s
                img.visibility = if (r.song == null) View.GONE else View.VISIBLE
                img.setImageDrawable(null); img.tag = null
                r.song?.let { thumb(it, img, 160) }
                view.setOnClickListener { r.click() }
                view.setOnLongClickListener { r.long?.invoke(); r.long != null }
                return view
            }
        }
    }

    private fun isOnline(): Boolean = try {
        val cm = getSystemService(ConnectivityManager::class.java)
        val n = cm.activeNetwork
        val caps = if (n != null) cm.getNetworkCapabilities(n) else null
        caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    } catch (_: Exception) { false }

    private fun onlineRows(q: String): List<Row> {
        val sub = if (isOnline()) "Se abre la app o la web" else "Sin internet"
        return listOf(
            Row("🎧  Buscar «$q» en Spotify", sub) { openSearch(true, q) },
            Row("▶  Buscar «$q» en YouTube", sub) { openSearch(false, q) }
        )
    }

    private fun openSearch(spotify: Boolean, q: String) {
        if (!isOnline()) { toast("Sin internet"); return }
        val e = Uri.encode(q)
        try {
            if (spotify) {
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("spotify:search:$e"))) }
                catch (_: Exception) { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://open.spotify.com/search/$e"))) }
            } else startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=$e")))
        } catch (_: Exception) { toast("No se pudo abrir") }
    }

    private fun buildIntro(): View {
        val layer = FrameLayout(this).apply { setBackgroundColor(Color.BLACK); isClickable = true }
        introLayer = layer
        val nature = NatureIntro(this, emblem(400))
        val vv = VideoView(this).apply { visibility = View.GONE }
        layer.addView(nature, FrameLayout.LayoutParams(-1, -1))
        layer.addView(vv, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
        val skip = txt("Saltar ›", 14f, Color.WHITE).apply {
            setPadding(dp(16), dp(8), dp(16), dp(8)); background = rounded(Color.parseColor("#66000000"), 16)
            setOnClickListener { endIntro(layer) }
        }
        layer.addView(skip, FrameLayout.LayoutParams(-2, -2, Gravity.END or Gravity.BOTTOM).apply { setMargins(0, 0, dp(16), dp(40)) })
        if (!prefs.getBoolean("intro_on", true)) { layer.visibility = View.GONE; return layer }
        val video = prefs.getString("intro_video", null)
        if (video != null) {
            try {
                nature.visibility = View.GONE; vv.visibility = View.VISIBLE
                vv.setOnCompletionListener { vv.visibility = View.GONE; nature.visibility = View.VISIBLE; nature.play(0.8f) { endIntro(layer) } }
                vv.setOnErrorListener { _, _, _ -> vv.visibility = View.GONE; nature.visibility = View.VISIBLE; nature.play(0f) { endIntro(layer) }; true }
                vv.setVideoURI(Uri.parse(video)); vv.start()
            } catch (_: Exception) { nature.play(0f) { endIntro(layer) } }
        } else nature.play(0f) { endIntro(layer) }
        return layer
    }

    private fun endIntro(layer: View) {
        if (layer.visibility != View.VISIBLE) return
        layer.animate().alpha(0f).setDuration(500).withEndAction { layer.visibility = View.GONE }.start()
    }

    private fun buildHome(): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(4), dp(16), dp(8)) }
        val hr = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        box.addView(txt(if (hr < 12) "Buenos días" else if (hr < 19) "Buenas tardes" else "Buenas noches", 26f, Color.WHITE, true))
        box.addView(txt("Tu música. Tu espacio.", 13f, GRAY).apply { setPadding(0, 0, 0, dp(12)) })
        val hero = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(dp(18), dp(16), dp(14), dp(16))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.parseColor("#7C4DFF"), Color.parseColor("#FF4F9A"))).apply { cornerRadius = dp(22).toFloat() }
        }
        val ht = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        ht.addView(txt("Dale play a todo", 20f, Color.WHITE, true))
        ht.addView(txt("${songs.size} canciones en tu teléfono", 12f, Color.parseColor("#F1E8FF")))
        ht.addView(btn("▶  Aleatorio") { shuffleAll() }.apply {
            setTextColor(Color.BLACK); background = rounded(GREEN, 24); setPadding(dp(22), dp(6), dp(22), dp(6))
            layoutParams = LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(10) }
        })
        hero.addView(ht, LinearLayout.LayoutParams(0, -2, 1f))
        hero.addView(ImageView(this).apply { setImageBitmap(emblem(220)) }, LinearLayout.LayoutParams(dp(86), dp(86)))
        box.addView(hero, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        box.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(chipRow(listOf("❤ Favoritas", "🎤 Artistas", "💿 Álbumes"), -1) { i ->
                page = 2; libSub = if (i == 0) 2 else i - 1; fKind = ""; refresh()
            })
        })
        fun carousel(title: String, items: List<Pair<String, Song>>, kind: String, round: Boolean) {
            if (items.isEmpty()) return
            box.addView(txt(title, 18f, Color.WHITE, true).apply { setPadding(0, dp(18), 0, dp(8)) })
            val row = LinearLayout(this)
            items.forEach { (name, s) ->
                val card = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL; setPadding(0, 0, dp(12), 0)
                    setOnClickListener { fKind = kind; fVal = name; refresh() }
                }
                val sz = dp(if (round) 104 else 128)
                val img = roundImg(if (round) 64 else 14)
                card.addView(img, LinearLayout.LayoutParams(sz, sz))
                thumb(s, img, 320)
                card.addView(txt(name, 13f, Color.WHITE).apply { setSingleLine(true); setWidth(sz); setPadding(0, dp(6), 0, 0) })
                row.addView(card)
            }
            box.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) })
        }
        carousel("Álbumes para ti", songs.groupBy { it.album }.map { (k, v) -> Pair(k, v.first()) }.take(14), "b", false)
        carousel("Artistas", songs.groupBy { it.artist }.map { (k, v) -> Pair(k, v.first()) }.take(14), "a", true)
        box.addView(txt("Todas las canciones", 18f, Color.WHITE, true).apply { setPadding(0, dp(20), 0, dp(4)) })
        return box
    }

    private fun buildMain(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(30), 0, 0) }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16), dp(6), dp(6), dp(4)) }
        head.addView(ImageView(this).apply {
            setImageBitmap(emblem(120))
            setOnClickListener { onLogoTap() }
        }, LinearLayout.LayoutParams(dp(34), dp(34)))
        head.addView(txt(
            when {
                isDev() && isPro() -> "L.E.B · DEV · PRO"
                isDev() -> "L.E.B · DEV"
                isPro() -> "L.E.B computing · PRO"
                else -> "L.E.B computing"
            }, 18f, Color.WHITE, true
        ).apply {
            setPadding(dp(10), 0, 0, 0); layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        })
        head.addView(btn("⚙") { openSettings() }.apply { textSize = 22f })
        col.addView(head)
        offlineBar = txt("📴  Sin internet · tu música sigue funcionando", 12f, Color.parseColor("#FFD59A")).apply {
            gravity = Gravity.CENTER; setPadding(dp(8), dp(5), dp(8), dp(5))
            setBackgroundColor(Color.parseColor("#55000000")); visibility = View.GONE
        }
        col.addView(offlineBar)
        controls = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(controls)
        searchBox = EditText(this).apply {
            hint = "¿Qué quieres escuchar?"; setHintTextColor(Color.parseColor("#777777"))
            setTextColor(Color.BLACK); setSingleLine(true)
            background = rounded(Color.WHITE, 8); setPadding(dp(14), dp(10), dp(14), dp(10))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(16), dp(6), dp(16), dp(4)) }
        }
        searchBox.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { query = s.toString(); rebuildRows() }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        list = ListView(this).apply { divider = null }
        col.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        mini = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = rounded(Color.parseColor("#E61B1B24"), 12); visibility = View.GONE
        }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(4)) }
        miniArt = roundImg(6)
        top.addView(miniArt, LinearLayout.LayoutParams(dp(44), dp(44)))
        val mc = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
        miniT = txt("", 15f, Color.WHITE, true).apply { setSingleLine(true) }
        miniS = txt("", 12f, GRAY).apply { setSingleLine(true) }
        mc.addView(miniT); mc.addView(miniS)
        top.addView(mc, LinearLayout.LayoutParams(0, -2, 1f))
        miniPlay = btn("▶") { togglePlay() }.apply { textSize = 24f }
        top.addView(miniPlay)
        mini.addView(top)
        miniProg = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 1000 }
        mini.addView(miniProg, LinearLayout.LayoutParams(-1, dp(3)).apply { setMargins(dp(10), 0, dp(10), dp(6)) })
        mini.setOnClickListener { full.visibility = View.VISIBLE }
        col.addView(mini, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(8), dp(4), dp(8), dp(4)) })
        val nav = LinearLayout(this).apply { setBackgroundColor(Color.parseColor("#E6000000")) }
        navBtns = listOf("🏠\nInicio", "🔍\nBuscar", "📚\nBiblioteca").mapIndexed { i, n ->
            btn(n, 1f) { page = i; fKind = ""; refresh() }.apply { textSize = 13f }
        }
        navBtns.forEach { nav.addView(it) }
        col.addView(nav)
        return col
    }

    /** Reproductor completo: letras dinámicas ABAJO (sin pantalla aparte). */
    private fun buildFull(): View {
        full = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(28), dp(22), dp(8))
            visibility = View.GONE; isClickable = true
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.parseColor("#4A36B0"), Color.parseColor("#0B0B12")))
        }
        full.addView(btn("⌄") { full.visibility = View.GONE }.apply { textSize = 26f })
        art = roundImg(14).apply { elevation = dp(14).toFloat() }
        full.addView(art, LinearLayout.LayoutParams(-1, 0, 1.1f).apply { topMargin = dp(4) })
        val tr = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(10), 0, 0) }
        val tc = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        pT = txt("", 22f, Color.WHITE, true).apply { setSingleLine(true) }
        pS = txt("", 14f, GRAY).apply { setSingleLine(true) }
        tc.addView(pT); tc.addView(pS)
        tr.addView(tc, LinearLayout.LayoutParams(0, -2, 1f))
        favBtn = btn("♡") { toggleFav(current()) }.apply { textSize = 26f }
        tr.addView(favBtn)
        full.addView(tr)
        seek = SeekBar(this)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { if (user) ctrl?.seekTo(p.toLong()) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        full.addView(seek)
        timeTv = txt("0:00 / 0:00", 12f, GRAY).apply { gravity = Gravity.CENTER }
        full.addView(timeTv)
        val ctl = LinearLayout(this).apply { gravity = Gravity.CENTER }
        pShuf = btn("🔀", 1f) { ctrl?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled }; syncUi() }
        pRep = btn("🔁", 1f) { ctrl?.let { it.repeatMode = (it.repeatMode + 1) % 3 }; syncUi() }
        pPlay = btn("▶", 0f) { togglePlay() }.apply {
            textSize = 28f; setTextColor(Color.BLACK); background = rounded(GREEN, 40)
            layoutParams = LinearLayout.LayoutParams(dp(76), dp(76)).apply { setMargins(dp(8), 0, dp(8), 0) }
        }
        ctl.addView(pShuf)
        ctl.addView(btn("⏮", 1f) { ctrl?.seekToPrevious() }.apply { textSize = 24f })
        ctl.addView(pPlay)
        ctl.addView(btn("⏭", 1f) { ctrl?.seekToNext() }.apply { textSize = 24f })
        ctl.addView(pRep)
        full.addView(ctl)

        // Letras dinámicas abajo (seguimiento en vivo)
        bottomLyricsScroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            layoutParams = LinearLayout.LayoutParams(-1, dp(120)).apply { topMargin = dp(8) }
        }
        bottomLyrics = TextView(this).apply {
            gravity = Gravity.CENTER
            textSize = lyricSize().toFloat()
            setTextColor(Color.WHITE)
            setLineSpacing(dp(6).toFloat(), 1.15f)
            setPadding(dp(8), dp(4), dp(8), dp(4))
            text = "La letra aparece aquí con el seguimiento"
            setOnLongClickListener { editLyrics(); true }
        }
        bottomLyricsScroll.addView(bottomLyrics)
        full.addView(bottomLyricsScroll)

        val ex = LinearLayout(this).apply { gravity = Gravity.CENTER }
        sleepBtn = btn("⏲ Dormir", 1f) { sleepDialog() }.apply { textSize = 12f }
        ex.addView(btn("✎ Editar letra", 1f) { editLyrics() }.apply { textSize = 12f })
        ex.addView(btn("⚡ Velocidad", 1f) { speedDialog() }.apply { textSize = 12f })
        ex.addView(sleepBtn)
        full.addView(ex)
        return full
    }

    private fun updateBottomLyrics() {
        if (!showLyricsOn()) {
            bottomLyrics.text = "Letras ocultas · Activalas en Ajustes"
            return
        }
        if (lyLines.isEmpty()) {
            bottomLyrics.text = lyStatus.ifBlank { "Buscando letra…" }
            return
        }
        val startIdx = if (lySynced && lyActive >= 0) (lyActive - 1).coerceAtLeast(0) else 0
        val endIdx = if (lySynced && lyActive >= 0) (lyActive + 2).coerceAtMost(lyLines.lastIndex) else minOf(4, lyLines.lastIndex)
        val sb = SpannableStringBuilder()
        for (i in startIdx..endIdx) {
            if (sb.isNotEmpty()) sb.append("\n")
            val start = sb.length
            val line = lyLines[i]
            val display = line.text.ifBlank { "♪" }
            sb.append(display)
            val end = sb.length
            if (lySynced && i == lyActive) {
                sb.setSpan(ForegroundColorSpan(Color.WHITE), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                sb.setSpan(StyleSpan(Typeface.BOLD), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                sb.setSpan(RelativeSizeSpan(1.15f), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            } else {
                sb.setSpan(ForegroundColorSpan(Color.parseColor("#88FFFFFF")), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
        }
        bottomLyrics.text = sb
        val midLine = if (lySynced && lyActive >= 0) (lyActive - startIdx).coerceAtLeast(0) else 0
        bottomLyrics.post {
            try {
                val layout = bottomLyrics.layout ?: return@post
                if (layout.lineCount == 0) return@post
                val mid = midLine.coerceIn(0, layout.lineCount - 1)
                val y = layout.getLineTop(mid)
                bottomLyricsScroll.smoothScrollTo(0, (y - bottomLyricsScroll.height / 3).coerceAtLeast(0))
            } catch (_: Exception) {}
        }
    }

    private fun setLyrics(raw: String) {
        val (lines, synced) = Lyrics.parse(raw)
        lyRaw = raw; lyLines = lines; lySynced = synced
        lyTrans = arrayOfNulls(lines.size); lyShowTrans = false; lyActive = -1
        lyStatus = if (lines.isEmpty()) "Letra vacía. Mantené pulsado o Editar letra." else ""
        updateBottomLyrics()
    }

    private fun loadLyrics(s: Song) {
        if (lySong == s.id) return
        lySong = s.id; lyLines = emptyList(); lyRaw = null; lyTrans = arrayOfNulls(0); lyActive = -1
        if (!showLyricsOn()) { lyStatus = "Letras ocultas"; updateBottomLyrics(); return }
        val saved = prefs.getString("lyr_${s.id}", null)
        if (saved != null) { setLyrics(saved); return }
        if (prefs.getBoolean("lyn_${s.id}", false)) {
            lyStatus = "Sin letra · tocá Editar letra"
            updateBottomLyrics(); return
        }
        lyStatus = "Buscando letra…"; updateBottomLyrics()
        val tree = treeUri(); val kw = keyword(); val online = prefs.getBoolean("ly_online", true) && isOnline()
        Thread {
            var raw: String? = null
            try { if (tree != null) raw = Lyrics.findInTree(this, tree, s.title, s.artist, kw) } catch (_: Exception) {}
            if (raw == null && online) raw = Lyrics.fetchOnline(s.title, s.artist)
            val found = raw
            runOnUiThread {
                if (lySong != s.id) return@runOnUiThread
                if (found != null) {
                    prefs.edit().putString("lyr_${s.id}", found).apply()
                    setLyrics(found)
                } else {
                    lyStatus = if (!isOnline()) "Sin internet · Editar letra para pegarla"
                    else "No encontré letra · Editar letra"
                    updateBottomLyrics()
                }
            }
        }.start()
    }

    private fun translator(src: String, dst: String): Translator = translators.getOrPut("$src>$dst") {
        Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(src).setTargetLanguage(dst).build())
    }

    private fun downloadLangs() {
        if (!isOnline()) { toast("Necesitas internet"); return }
        try {
            translator(TranslateLanguage.ENGLISH, TranslateLanguage.SPANISH).downloadModelIfNeeded()
                .addOnSuccessListener { toast("Inglés → Español listo") }
            translator(TranslateLanguage.SPANISH, TranslateLanguage.ENGLISH).downloadModelIfNeeded()
                .addOnSuccessListener { toast("Español → Inglés listo") }
        } catch (_: Throwable) { toast("Traducción no disponible") }
    }

    private fun editLyrics() {
        val s = current() ?: return
        val e = EditText(this).apply {
            setText(lyRaw ?: ""); hint = "Pega la letra (texto o .lrc con tiempos)"; minLines = 8; gravity = Gravity.TOP
        }
        AlertDialog.Builder(this).setTitle("Editar letra").setView(e)
            .setPositiveButton("Guardar") { _, _ ->
                val t = e.text.toString()
                if (t.isBlank()) { toast("Vacía"); return@setPositiveButton }
                prefs.edit().putString("lyr_${s.id}", t).remove("lyn_${s.id}").apply()
                setLyrics(t)
            }
            .setNeutralButton("Borrar") { _, _ ->
                prefs.edit().remove("lyr_${s.id}").putBoolean("lyn_${s.id}", true).apply()
                lyLines = emptyList(); lyRaw = null; lyStatus = "Letra borrada"; updateBottomLyrics()
            }
            .setNegativeButton("Cancelar", null).show()
    }

    private fun buildSettings(): View {
        settings = ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#0A0A12")); visibility = View.GONE; isClickable = true
        }
        setCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(34), dp(16), dp(30)) }
        settings.addView(setCol)
        return settings
    }

    private fun openSettings() { fillSettings(); settings.visibility = View.VISIBLE }

    private fun settingsCard(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = cardBg()
        setPadding(dp(16), dp(14), dp(16), dp(14))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) }
    }

    private fun sw(t: String, key: String, def: Boolean, on: (Boolean) -> Unit = {}) = Switch(this).apply {
        text = t; setTextColor(Color.WHITE); isChecked = prefs.getBoolean(key, def)
        setPadding(0, dp(6), 0, dp(6))
        setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean(key, c).apply(); on(c) }
    }

    private fun secTitle(t: String, color: Int = ACCENT) = txt(t, 13f, color, true).apply {
        setPadding(0, 0, 0, dp(8))
    }

    private fun action(t: String, f: () -> Unit) = btn(t, 0f, f).apply {
        gravity = Gravity.START or Gravity.CENTER_VERTICAL
        background = rounded(Color.parseColor("#28FFFFFF"), 12)
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(4), 0, dp(4)) }
    }

    private fun fillSettings() {
        setCol.removeAllViews()
        // Header llamativo
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.parseColor("#7C4DFF"), Color.parseColor("#FF4F9A"))).apply { cornerRadius = dp(22).toFloat() }
            setPadding(dp(20), dp(22), dp(20), dp(22))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(16) }
        }
        val topRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        topRow.addView(btn("←") { settings.visibility = View.GONE }.apply { textSize = 22f })
        topRow.addView(txt("Ajustes", 22f, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(topRow)
        header.addView(ImageView(this).apply { setImageBitmap(emblem(200)) }, LinearLayout.LayoutParams(dp(72), dp(72)).apply {
            gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(10)
        })
        header.addView(txt("L.E.B computing", 20f, Color.WHITE, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, 0) })
        header.setOnClickListener { onLogoTap() }
        header.addView(txt("Versión 1.5-beta · Dev tools · Pro local", 12f, Color.parseColor("#F1E8FF")).apply { gravity = Gravity.CENTER })
        setCol.addView(header)

        // Letras
        val c1 = settingsCard()
        c1.addView(secTitle("♪  LETRAS", GREEN))
        c1.addView(sw("Mostrar letras abajo en el reproductor", "ly_show", true) { lySong = -1L; syncUi() })
        c1.addView(sw("Buscar letras en internet", "ly_online", true))
        val tree = treeUri()
        val folder = tree?.let {
            try { DocumentsContract.getTreeDocumentId(it).substringAfter(':').ifBlank { "Almacenamiento" } } catch (_: Exception) { "elegida" }
        }
        c1.addView(action("📁  Carpeta de letras: ${folder ?: "ninguna"}") {
            try {
                startActivityForResult(
                    Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION), 7
                )
            } catch (_: Exception) { toast("No se pudo abrir") }
        })
        if (tree != null) c1.addView(action("✕  Quitar carpeta") { prefs.edit().remove("ly_tree").apply(); lySong = -1L; fillSettings() })
        c1.addView(txt("Palabra clave en el archivo (opcional)", 12f, GRAY).apply { setPadding(0, dp(8), 0, 0) })
        c1.addView(EditText(this).apply {
            setText(keyword()); hint = "ej. letra"; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE); setSingleLine(true)
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { prefs.edit().putString("ly_kw", s.toString().trim()).apply(); lySong = -1L }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        })
        val sizeTv = txt("Tamaño de letra: ${lyricSize()}", 14f, Color.WHITE).apply { setPadding(0, dp(10), 0, 0) }
        c1.addView(sizeTv)
        c1.addView(SeekBar(this).apply {
            max = 16; progress = (lyricSize() - 12).coerceIn(0, 16)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    prefs.edit().putInt("ly_size", 12 + p).apply()
                    sizeTv.text = "Tamaño de letra: ${12 + p}"
                    bottomLyrics.textSize = (12 + p).toFloat()
                    updateBottomLyrics()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
        setCol.addView(c1)

        // Música
        val c2 = settingsCard()
        c2.addView(secTitle("🎵  MÚSICA", PINK))
        c2.addView(action("🔄  Reescanear música") { if (hasAudioPerm()) scan() else toast("Falta permiso") })
        c2.addView(sw("Mostrar audios cortos (< 30 s)", "short", false) { if (hasAudioPerm()) scan() })
        c2.addView(sw("Mantener tono al cambiar velocidad", "pitch", false) { keepPitch = it; applySpeed() })
        setCol.addView(c2)

        // Apariencia
        val c3 = settingsCard()
        c3.addView(secTitle("✨  APARIENCIA", ACCENT))
        c3.addView(action("🖼  Elegir foto de fondo") {
            try {
                startActivityForResult(
                    Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*")
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION), 8
                )
            } catch (_: Exception) { toast("No se pudo abrir") }
        })
        c3.addView(action("🌌  Fondo del espacio") { prefs.edit().remove("bg").apply(); loadBackground() })
        setCol.addView(c3)

        // Offline / trad
        val c4 = settingsCard()
        c4.addView(secTitle("📡  SIN INTERNET", Color.parseColor("#FFD59A")))
        c4.addView(action("⬇  Descargar idiomas para traducir") { downloadLangs() })
        c4.addView(txt("Sin conexión: música, letras guardadas e idiomas descargados.", 12f, GRAY))
        setCol.addView(c4)

        // Intro
        val c5 = settingsCard()
        c5.addView(secTitle("🎬  INTRO", Color.parseColor("#7EC8FF")))
        c5.addView(sw("Mostrar intro al abrir", "intro_on", true))
        c5.addView(action("Elegir video de entrada") {
            try {
                startActivityForResult(
                    Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("video/*")
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION), 9
                )
            } catch (_: Exception) { toast("No se pudo abrir") }
        })
        c5.addView(action("Usar intro de naturaleza") { prefs.edit().remove("intro_video").apply(); toast("Listo") })
        setCol.addView(c5)

        // Desarrollador (oculto: 7 toques en el logo + PIN lebdev)
        if (isDev()) {
            val cDev = settingsCard()
            cDev.addView(secTitle("🛠  DESARROLLADOR", Color.parseColor("#FF6B6B")))
            cDev.addView(txt("Solo para builds de prueba · v1.5-beta", 12f, GRAY))
            cDev.addView(sw("Forzar PRO en este dispositivo", "dev_force_pro", false) {
                toast(if (it) "PRO activado (dev)" else "PRO desactivado")
                refresh(); syncUi()
            })
            cDev.addView(sw("Mostrar info de depuración en toasts", "dev_toasts", false))
            cDev.addView(action("📊  Estado: canciones=${songs.size} · Pro=${isPro()} · online=${isOnline()}") {
                toast("songs=${songs.size} pro=${isPro()} online=${isOnline()}")
            })
            cDev.addView(action("📋  Ver último crash guardado") {
                val c = prefs.getString("crash", null) ?: prefs.getString("last_crash_view", "Sin crashes guardados")
                AlertDialog.Builder(this).setTitle("Crash").setMessage(c).setPositiveButton("OK", null).show()
            })
            cDev.addView(action("🔁  Resetear intro (mostrar de nuevo)") {
                prefs.edit().putBoolean("intro_on", true).remove("intro_video").apply()
                toast("Intro lista para la próxima apertura")
            })
            cDev.addView(action("🧹  Limpiar caché de portadas") {
                cache.evictAll(); logos.clear(); toast("Caché limpia")
            })
            cDev.addView(action("⭐  Activar PRO permanente (local)") {
                prefs.edit().putBoolean("pro", true).apply(); toast("PRO local ON"); refresh()
            })
            cDev.addView(action("☆  Quitar PRO permanente") {
                prefs.edit().putBoolean("pro", false).putBoolean("dev_force_pro", false).apply()
                toast("PRO off"); fillSettings(); refresh()
            })
            cDev.addView(action("🔒  Cerrar modo desarrollador") {
                prefs.edit().putBoolean("dev_mode", false).putBoolean("dev_force_pro", false).apply()
                toast("Modo desarrollador desactivado"); fillSettings(); refresh()
            })
            setCol.addView(cDev)
        } else {
            val hint = settingsCard()
            hint.addView(secTitle("🛠  DESARROLLADOR", GRAY))
            hint.addView(txt("Tocá 7 veces el logo L.E.B (inicio o ajustes) e ingresá el PIN para abrir herramientas de la beta.", 12f, GRAY))
            setCol.addView(hint)
        }

        // Datos
        val c6 = settingsCard()
        c6.addView(secTitle("🗂  DATOS", GRAY))
        c6.addView(action("Borrar favoritas") { prefs.edit().remove("fav").apply(); refresh(); syncUi(); toast("Listo") })
        c6.addView(action("Borrar letras guardadas") {
            val e = prefs.edit()
            prefs.all.keys.filter { it.startsWith("lyr_") || it.startsWith("lyn_") }.forEach { e.remove(it) }
            e.apply(); lySong = -1L; syncUi(); toast("Listo")
        })
        setCol.addView(c6)

        setCol.addView(btn("Cerrar ajustes") { settings.visibility = View.GONE }.apply {
            setTextColor(Color.BLACK); background = rounded(GREEN, 16)
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) }
        })
    }

    private fun speedDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(10), dp(20), 0) }
        val tv = TextView(this).apply { text = "Velocidad: %.2fx".format(rate); textSize = 16f }
        val sb = SeekBar(this).apply { max = 30; progress = ((rate - 0.5f) / 0.05f).toInt().coerceIn(0, 30) }
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                if (u) { setRate(0.5f + p * 0.05f); tv.text = "Velocidad: %.2fx".format(rate) }
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        val row = LinearLayout(this)
        fun preset(t: String, r: Float) = btn(t, 1f) {
            setRate(r); sb.progress = ((r - 0.5f) / 0.05f).toInt(); tv.text = "Velocidad: %.2fx".format(rate)
        }
        row.addView(preset("🐢 Slowed", 0.8f)); row.addView(preset("Normal", 1f)); row.addView(preset("🐇 Sped up", 1.25f))
        box.addView(tv); box.addView(sb); box.addView(row)
        AlertDialog.Builder(this).setTitle("Velocidad").setView(box).setPositiveButton("Listo", null).show()
    }

    private fun sleepDialog() {
        val o = arrayOf("15 minutos", "30 minutos", "45 minutos", "1 hora", "Cancelar")
        val m = intArrayOf(15, 30, 45, 60, 0)
        AlertDialog.Builder(this).setTitle("Temporizador").setItems(o) { _, i ->
            sleepAt = if (m[i] == 0) 0L else System.currentTimeMillis() + m[i] * 60000L
            if (m[i] == 0) sleepBtn.text = "⏲ Dormir"
        }.show()
    }

    private fun syncUi() {
        try {
            val c = ctrl ?: return
            val s = current()
            mini.visibility = if (s != null) View.VISIBLE else View.GONE
            if (s != null && pT.text.toString() != s.title) {
                pT.text = s.title; pS.text = s.artist; miniT.text = s.title; miniS.text = s.artist
                thumb(s, art, 600) { applyTint(it) }; thumb(s, miniArt, 160)
                list.invalidateViews()
            }
            if (s != null) loadLyrics(s)
            val icon = if (c.isPlaying) "⏸" else "▶"
            pPlay.text = icon; miniPlay.text = icon
            pShuf.alpha = if (c.shuffleModeEnabled) 1f else 0.4f
            pRep.alpha = if (c.repeatMode != Player.REPEAT_MODE_OFF) 1f else 0.4f
            pRep.text = if (c.repeatMode == Player.REPEAT_MODE_ONE) "🔂" else "🔁"
            favBtn.text = if (isFav(s)) "♥" else "♡"
            favBtn.setTextColor(if (isFav(s)) GREEN else Color.WHITE)
        } catch (_: Exception) {}
    }

    private fun fmt(ms: Long) = "%d:%02d".format(ms / 60000, ms / 1000 % 60)

    private fun tick() {
        try {
            if (netTick++ % 6 == 0) offlineBar.visibility = if (isOnline()) View.GONE else View.VISIBLE
            val c = ctrl
            if (c != null && c.currentMediaItem != null) {
                val d = c.duration; val pos = c.currentPosition
                if (d > 0) {
                    seek.max = d.toInt(); seek.progress = pos.toInt()
                    timeTv.text = "${fmt(pos)} / ${fmt(d)}"
                    miniProg.progress = (pos * 1000 / d).toInt()
                }
                if (lySynced && lyLines.isNotEmpty()) {
                    var idx = -1
                    for (i in lyLines.indices) {
                        if (lyLines[i].timeMs <= pos + 300) idx = i else break
                    }
                    if (idx != lyActive) {
                        lyActive = idx
                        updateBottomLyrics()
                    }
                }
            }
            if (sleepAt > 0) {
                val left = sleepAt - System.currentTimeMillis()
                if (left <= 0) { sleepAt = 0; ctrl?.pause(); sleepBtn.text = "⏲ Dormir" }
                else sleepBtn.text = "⏲ ${left / 60000 + 1} min"
            }
        } catch (_: Exception) {}
        h.postDelayed({ tick() }, 500)
    }
}
