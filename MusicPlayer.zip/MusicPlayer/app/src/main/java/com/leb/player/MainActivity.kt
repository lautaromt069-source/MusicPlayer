package com.leb.player

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.provider.MediaStore.Audio.Media as AM
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.util.LruCache
import android.util.Size
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.*
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import java.util.concurrent.Executor

class MainActivity : Activity() {
    data class Song(val id: Long, val title: String, val artist: String, val album: String, val albumId: Long, val uri: Uri)
    data class Row(val t: String, val s: String, val song: Song? = null, val long: (() -> Unit)? = null, val click: () -> Unit)

    private val GREEN = Color.parseColor("#1ED760")
    private val GRAY = Color.parseColor("#B3B3C0")
    private val h = Handler(Looper.getMainLooper())
    private val songs = ArrayList<Song>()
    private val cache = LruCache<String, Bitmap>(60)
    private val logos = HashMap<Int, Bitmap>()
    private val prefs by lazy { getSharedPreferences("leb", MODE_PRIVATE) }
    private var ctrl: MediaController? = null
    private var page = 0
    private var libSub = 0
    private var scope = 0
    private var fKind = ""
    private var fVal = ""
    private var query = ""
    private var rows: List<Row> = emptyList()
    private var keepPitch = false
    private var rate = 1f
    private var sleepAt = 0L
    // letras
    private var lyLines: List<Lyrics.Line> = emptyList()
    private var lySynced = false
    private var lyRaw: String? = null
    private var lyTrans: Array<String?> = arrayOfNulls(0)
    private var lyShowTrans = false
    private var lyActive = -1
    private var lySong = -1L
    private var lyStatus = ""

    private lateinit var bg: ImageView
    private lateinit var controls: LinearLayout
    private lateinit var searchBox: EditText
    private lateinit var list: ListView
    private lateinit var navBtns: List<Button>
    private lateinit var mini: LinearLayout
    private lateinit var miniArt: ImageView
    private lateinit var miniT: TextView
    private lateinit var miniS: TextView
    private lateinit var miniPlay: Button
    private lateinit var miniProg: ProgressBar
    private lateinit var full: LinearLayout
    private lateinit var art: ImageView
    private lateinit var pT: TextView
    private lateinit var pS: TextView
    private lateinit var pLine: TextView
    private lateinit var seek: SeekBar
    private lateinit var timeTv: TextView
    private lateinit var pPlay: Button
    private lateinit var pShuf: Button
    private lateinit var pRep: Button
    private lateinit var favBtn: Button
    private lateinit var sleepBtn: Button
    private lateinit var lyView: LinearLayout
    private lateinit var lyList: ListView
    private lateinit var lyTitle: TextView
    private lateinit var lyEmpty: TextView
    private lateinit var settings: ScrollView
    private lateinit var setCol: LinearLayout

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun rounded(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }
    private fun txt(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }
    private fun btn(t: String, w: Float = 0f, f: () -> Unit) = Button(this).apply {
        text = t; setTextColor(Color.WHITE); isAllCaps = false; setBackgroundColor(Color.TRANSPARENT)
        layoutParams = LinearLayout.LayoutParams(if (w > 0) 0 else -2, -2, w); setOnClickListener { f() }
    }
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private fun showLyricsOn() = prefs.getBoolean("ly_show", true)
    private fun lyricSize() = prefs.getInt("ly_size", 20)
    private fun keyword() = prefs.getString("ly_kw", "") ?: ""
    private fun treeUri(): Uri? = prefs.getString("ly_tree", null)?.let { Uri.parse(it) }

    // ================== Ciclo de vida ==================
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { prefs.edit().putString("crash", Log.getStackTraceString(e).take(1800)).commit() } catch (x: Exception) {}
            old?.uncaughtException(t, e)
        }
        keepPitch = prefs.getBoolean("pitch", false)
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        bg = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        root.addView(bg)
        root.addView(View(this).apply { setBackgroundColor(Color.parseColor("#99000000")) })
        root.addView(buildMain()); root.addView(buildFull()); root.addView(buildLyrics()); root.addView(buildSettings())
        val splash = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; isClickable = true
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.parseColor("#2A1B5E"), Color.parseColor("#05010F")))
            addView(ImageView(this@MainActivity).apply { setImageBitmap(emblem(360)) }, LinearLayout.LayoutParams(dp(130), dp(130)))
            addView(txt("L.E.B computing", 20f, Color.parseColor("#D9CFFF")).apply { letterSpacing = 0.2f; setPadding(0, dp(16), 0, 0) })
        }
        root.addView(splash)
        h.postDelayed({ splash.animate().alpha(0f).setDuration(500).withEndAction { splash.visibility = View.GONE }.start() }, 1800)
        setContentView(root)
        loadBackground()
        refresh()

        val perms = if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
        else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        if (hasAudioPerm()) scan()
        if (perms.any { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }) requestPermissions(perms, 1)
        connect()
        tick()
        prefs.getString("crash", null)?.let { c ->
            prefs.edit().remove("crash").apply()
            h.postDelayed({
                try { AlertDialog.Builder(this).setTitle("La app se cerró la última vez").setMessage(c).setPositiveButton("Cerrar", null).show() } catch (e: Exception) {}
            }, 2500)
        }
    }

    private fun hasAudioPerm() = checkSelfPermission(if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        if (hasAudioPerm()) scan() else toast("Necesito permiso para ver tu música")
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val u = data?.data ?: return
        if (res != RESULT_OK) return
        try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: Exception) {}
        if (req == 7) { prefs.edit().putString("ly_tree", u.toString()).apply(); lySong = -1L; fillSettings(); syncUi() }
        if (req == 8) { prefs.edit().putString("bg", u.toString()).apply(); loadBackground() }
    }

    override fun onBackPressed() {
        when {
            settings.visibility == View.VISIBLE -> settings.visibility = View.GONE
            lyView.visibility == View.VISIBLE -> lyView.visibility = View.GONE
            full.visibility == View.VISIBLE -> full.visibility = View.GONE
            fKind.isNotEmpty() -> { fKind = ""; refresh() }
            else -> super.onBackPressed()
        }
    }

    override fun onDestroy() { h.removeCallbacksAndMessages(null); try { ctrl?.release() } catch (e: Exception) {}; super.onDestroy() }

    // ================== Imágenes ==================
    private fun spaceBitmap(): Bitmap {
        val w = 540; val hh = 960
        val bm = Bitmap.createBitmap(w, hh, Bitmap.Config.ARGB_8888)
        val c = Canvas(bm); val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(0f, 0f, 0f, hh.toFloat(), Color.parseColor("#02010A"), Color.parseColor("#1A0B3D"), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w.toFloat(), hh.toFloat(), p)
        val r = java.util.Random(7)
        fun blob(x: Float, y: Float, rad: Float, col: Int) { p.shader = RadialGradient(x, y, rad, col, Color.TRANSPARENT, Shader.TileMode.CLAMP); c.drawCircle(x, y, rad, p) }
        blob(120f, 260f, 330f, Color.parseColor("#553A1FA8")); blob(430f, 520f, 380f, Color.parseColor("#44B02F8F")); blob(260f, 800f, 300f, Color.parseColor("#442A6FD0"))
        p.shader = null
        for (i in 0 until 260) { p.color = Color.argb(60 + r.nextInt(190), 255, 255, 255); c.drawCircle(r.nextFloat() * w, r.nextFloat() * hh, 0.5f + r.nextFloat() * 1.6f, p) }
        p.shader = RadialGradient(430f, 800f, 120f, intArrayOf(Color.parseColor("#FFB07A"), Color.parseColor("#B5476B"), Color.parseColor("#2B1040")), floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(430f, 820f, 110f, p)
        return bm
    }

    private fun loadBackground() {
        Thread {
            var bm: Bitmap? = null
            try {
                prefs.getString("bg", null)?.let { u ->
                    val o = BitmapFactory.Options().apply { inSampleSize = 4 }
                    contentResolver.openInputStream(Uri.parse(u))?.use { bm = BitmapFactory.decodeStream(it, null, o) }
                }
            } catch (e: Exception) {}
            val res = bm ?: spaceBitmap()
            runOnUiThread { bg.setImageBitmap(res) }
        }.start()
    }

    /** Emblema L.E.B (también se usa como portada cuando la canción no tiene). */
    private fun emblem(size: Int): Bitmap = logos.getOrPut(size) {
        val bm = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bm); val p = Paint(Paint.ANTI_ALIAS_FLAG); val s = size.toFloat()
        p.shader = LinearGradient(0f, 0f, s, s, Color.parseColor("#6D4BFF"), Color.parseColor("#1B1245"), Shader.TileMode.CLAMP)
        c.drawRoundRect(0f, 0f, s, s, s * 0.22f, s * 0.22f, p)
        p.shader = null; p.style = Paint.Style.STROKE; p.strokeWidth = s * 0.035f; p.color = Color.parseColor("#B9A8FF")
        c.drawCircle(s / 2, s / 2, s * 0.36f, p)
        p.style = Paint.Style.FILL; p.color = Color.WHITE; p.textAlign = Paint.Align.CENTER; p.isFakeBoldText = true; p.textSize = s * 0.22f
        c.drawText("L.E.B", s / 2, s * 0.53f, p)
        p.isFakeBoldText = false; p.color = Color.parseColor("#D9CFFF"); p.textSize = s * 0.085f
        c.drawText("computing", s / 2, s * 0.66f, p)
        bm
    }

    private fun art(s: Song) = ContentUris.withAppendedId(Uri.parse("content://media/external/audio/albumart"), s.albumId)

    private fun thumb(s: Song, iv: ImageView, size: Int) {
        val key = s.uri.toString() + size; iv.tag = key
        cache.get(key)?.let { iv.setImageBitmap(it); return }
        iv.setImageBitmap(emblem(size))
        if (Build.VERSION.SDK_INT < 29) return
        Thread {
            try {
                val bm = contentResolver.loadThumbnail(s.uri, Size(size, size), null)
                cache.put(key, bm)
                runOnUiThread { if (iv.tag == key) iv.setImageBitmap(bm) }
            } catch (e: Exception) {}
        }.start()
    }

    private fun roundImg(r: Int = 8) = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; background = rounded(Color.parseColor("#2A2A35"), r); clipToOutline = true; outlineProvider = ViewOutlineProvider.BACKGROUND }

    // ================== Motor de música ==================
    private val listener = object : Player.Listener {
        override fun onMediaItemTransition(m: MediaItem?, r: Int) { syncUi() }
        override fun onIsPlayingChanged(p: Boolean) { syncUi() }
        override fun onPlaybackStateChanged(s: Int) { syncUi() }
        override fun onPlayerError(e: PlaybackException) {
            toast("No se pudo reproducir esta canción")
            try { ctrl?.let { if (it.hasNextMediaItem()) { it.seekToNext(); it.prepare(); it.play() } } } catch (x: Exception) {}
        }
    }

    private fun connect() {
        try {
            val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
            val f = MediaController.Builder(this, token).buildAsync()
            f.addListener({
                try { ctrl = f.get(); ctrl?.addListener(listener); syncUi() } catch (e: Exception) { toast("No se pudo iniciar el reproductor") }
            }, Executor { h.post(it) })
        } catch (e: Exception) { toast("No se pudo iniciar el reproductor") }
    }

    private fun item(s: Song) = MediaItem.Builder().setMediaId(s.id.toString()).setUri(s.uri)
        .setMediaMetadata(MediaMetadata.Builder().setTitle(s.title).setArtist(s.artist).setAlbumTitle(s.album).setArtworkUri(art(s)).build()).build()

    private fun playList(l: List<Song>, i: Int) {
        val c = ctrl ?: run { toast("Conectando…"); return }
        try { c.setMediaItems(l.map { item(it) }, i, 0L); c.prepare(); c.play(); applySpeed(); full.visibility = View.VISIBLE } catch (e: Exception) { toast("No se pudo reproducir") }
    }

    private fun shuffleAll() {
        if (songs.isEmpty()) { toast("No hay música"); return }
        ctrl?.shuffleModeEnabled = true
        playList(songs, (Math.random() * songs.size).toInt())
    }

    private fun current(): Song? = ctrl?.currentMediaItem?.mediaId?.let { id -> songs.find { it.id.toString() == id } }
    private fun applySpeed() { try { ctrl?.setPlaybackParameters(PlaybackParameters(rate, if (keepPitch) 1f else rate)) } catch (e: Exception) {} }
    private fun setRate(r: Float) { rate = r; applySpeed() }
    private fun togglePlay() { ctrl?.let { if (it.isPlaying) it.pause() else it.play() } }

    // ================== Biblioteca ==================
    private fun scan() {
        Thread {
            val out = ArrayList<Song>()
            try {
                val base = AM.EXTERNAL_CONTENT_URI
                val shortSel = if (prefs.getBoolean("short", false)) "" else "AND ${AM.DURATION}>=30000 "
                contentResolver.query(base, arrayOf(AM._ID, AM.TITLE, AM.ARTIST, AM.ALBUM, AM.ALBUM_ID),
                    "${AM.IS_MUSIC}!=0 ${shortSel}AND ${AM.DATA} NOT LIKE '%WhatsApp%'", null, "${AM.TITLE} COLLATE NOCASE ASC")?.use { c ->
                    while (c.moveToNext()) {
                        val artist = c.getString(2)?.takeIf { it != "<unknown>" } ?: "Artista desconocido"
                        out.add(Song(c.getLong(0), c.getString(1) ?: "Sin título", artist, c.getString(3) ?: "Álbum desconocido", c.getLong(4), ContentUris.withAppendedId(base, c.getLong(0))))
                    }
                }
            } catch (e: Exception) {}
            runOnUiThread { songs.clear(); songs.addAll(out); refresh(); if (out.isEmpty()) toast("No encontré música en tu teléfono") else toast("${out.size} canciones") }
        }.start()
    }

    private fun favs(): MutableSet<String> = HashSet(prefs.getStringSet("fav", emptySet()) ?: emptySet())
    private fun isFav(s: Song?) = s != null && favs().contains(s.id.toString())
    private fun toggleFav(s: Song?) {
        if (s == null) return
        val set = favs()
        if (!set.remove(s.id.toString())) set.add(s.id.toString())
        prefs.edit().putStringSet("fav", set).apply()
        syncUi(); rebuildRows()
    }

    private fun songRows(l: List<Song>) = l.mapIndexed { i, s -> Row(s.title, s.artist + if (isFav(s)) "  ♥" else "", s, { toggleFav(s) }) { playList(l, i) } }
    private fun groupRows(by: (Song) -> String, kind: String, q: String): List<Row> =
        songs.groupBy(by).filter { q.isEmpty() || it.key.contains(q, true) }.map { (k, v) -> Row(k, "${v.size} canciones", v.first()) { fKind = kind; fVal = k; refresh() } }

    private fun refresh() {
        buildControls(); rebuildRows()
        navBtns.forEachIndexed { i, b -> b.setTextColor(if (i == page) GREEN else GRAY) }
    }

    private fun chip(t: String, sel: Boolean, f: () -> Unit) = TextView(this).apply {
        text = t; textSize = 13f; setPadding(dp(14), dp(7), dp(14), dp(7))
        background = rounded(if (sel) Color.WHITE else Color.parseColor("#44FFFFFF"), 20); setTextColor(if (sel) Color.BLACK else Color.WHITE)
        setOnClickListener { f() }; layoutParams = LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }
    }

    private fun chipRow(names: List<String>, cur: Int, f: (Int) -> Unit) = LinearLayout(this).apply {
        setPadding(dp(12), 0, dp(12), 0)
        names.forEachIndexed { i, n -> addView(chip(n, i == cur) { f(i) }) }
    }

    private fun buildControls() {
        controls.removeAllViews()
        if (fKind.isNotEmpty()) { controls.addView(btn("‹ Volver   ·   $fVal") { fKind = ""; refresh() }.apply { setTextColor(GREEN) }); return }
        when (page) {
            0 -> controls.addView(btn("▶   Reproducir aleatorio") { shuffleAll() }.apply { background = rounded(GREEN, 26); setTextColor(Color.BLACK) },
                LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(16), dp(6), dp(16), dp(6)) })
            1 -> { controls.addView(searchBox); controls.addView(chipRow(listOf("Canciones", "Artistas", "Álbumes"), scope) { scope = it; refresh() }) }
            else -> controls.addView(chipRow(listOf("Artistas", "Álbumes", "Favoritas"), libSub) { libSub = it; refresh() })
        }
    }

    private fun rebuildRows() {
        val q = query.trim()
        rows = when {
            fKind.isNotEmpty() -> songRows(songs.filter { if (fKind == "a") it.artist == fVal else it.album == fVal })
            page == 0 -> songRows(songs)
            page == 1 -> when {
                q.isEmpty() -> listOf(Row("Busca canciones, artistas o álbumes", "") {})
                scope == 1 -> groupRows({ it.artist }, "a", q)
                scope == 2 -> groupRows({ it.album }, "b", q)
                else -> songRows(songs.filter { it.title.contains(q, true) || it.artist.contains(q, true) || it.album.contains(q, true) })
            }
            else -> when (libSub) { 0 -> groupRows({ it.artist }, "a", ""); 1 -> groupRows({ it.album }, "b", ""); else -> songRows(songs.filter { isFav(it) }) }
        }
        list.adapter = object : BaseAdapter() {
            override fun getCount() = rows.size
            override fun getItem(p: Int) = rows[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun getView(p: Int, v: View?, g: ViewGroup): View {
                val r = rows[p]
                val view = (v as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                    gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16), dp(6), dp(16), dp(6))
                    addView(roundImg(), LinearLayout.LayoutParams(dp(52), dp(52)))
                    addView(LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, 0, 0); addView(txt("", 15f, Color.WHITE).apply { setSingleLine(true) }); addView(txt("", 12f, GRAY).apply { setSingleLine(true) }) }, LinearLayout.LayoutParams(0, -2, 1f))
                }
                val img = view.getChildAt(0) as ImageView
                val col = view.getChildAt(1) as LinearLayout
                (col.getChildAt(0) as TextView).apply { text = r.t; setTextColor(if (r.song != null && r.song.id == current()?.id && r.long != null) GREEN else Color.WHITE) }
                (col.getChildAt(1) as TextView).text = r.s
                img.visibility = if (r.t.startsWith("Busca canciones")) View.GONE else View.VISIBLE
                img.setImageDrawable(null); img.tag = null
                r.song?.let { thumb(it, img, 160) }
                view.setOnClickListener { r.click() }
                view.setOnLongClickListener { r.long?.invoke(); r.long != null }
                return view
            }
        }
    }

    // ================== Pantallas ==================
    private fun buildMain(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(30), 0, 0) }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16), dp(6), dp(6), dp(4)) }
        head.addView(ImageView(this).apply { setImageBitmap(emblem(120)) }, LinearLayout.LayoutParams(dp(34), dp(34)))
        head.addView(txt("L.E.B computing", 20f, Color.WHITE, true).apply { setPadding(dp(10), 0, 0, 0); layoutParams = LinearLayout.LayoutParams(0, -2, 1f) })
        head.addView(btn("⚙") { openSettings() }.apply { textSize = 22f })
        col.addView(head)
        controls = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(controls)
        searchBox = EditText(this).apply {
            hint = "¿Qué quieres escuchar?"; setHintTextColor(Color.parseColor("#777777")); setTextColor(Color.BLACK); setSingleLine(true)
            background = rounded(Color.WHITE, 8); setPadding(dp(14), dp(10), dp(14), dp(10))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(16), dp(6), dp(16), dp(4)) }
        }
        searchBox.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { query = s.toString(); rebuildRows() }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        list = ListView(this).apply { divider = null }
        col.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        mini = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = rounded(Color.parseColor("#E61B1B24"), 12); visibility = View.GONE }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(4)) }
        miniArt = roundImg(6)
        top.addView(miniArt, LinearLayout.LayoutParams(dp(44), dp(44)))
        val mc = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
        miniT = txt("", 15f, Color.WHITE, true).apply { setSingleLine(true) }; miniS = txt("", 12f, GRAY).apply { setSingleLine(true) }
        mc.addView(miniT); mc.addView(miniS)
        top.addView(mc, LinearLayout.LayoutParams(0, -2, 1f))
        miniPlay = btn("▶") { togglePlay() }.apply { textSize = 24f }
        top.addView(miniPlay)
        mini.addView(top)
        miniProg = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 1000 }
        mini.addView(miniProg, LinearLayout.LayoutParams(-1, dp(3)).apply { setMargins(dp(10), 0, dp(10), dp(6)) })
        mini.setOnClickListener { full.visibility = View.VISIBLE }
        col.addView(mini, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(8), dp(4), dp(8), dp(4)) })
        val nav = LinearLayout(this).apply { setBackgroundColor(Color.parseColor("#E6000000")) }
        navBtns = listOf("🏠  Inicio", "🔍  Buscar", "📚  Biblioteca").mapIndexed { i, n -> btn(n, 1f) { page = i; fKind = ""; refresh() }.apply { textSize = 13f } }
        navBtns.forEach { nav.addView(it) }
        col.addView(nav)
        return col
    }

    private fun buildFull(): View {
        full = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(30), dp(22), dp(8)); visibility = View.GONE; isClickable = true
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.parseColor("#4A36B0"), Color.parseColor("#0B0B12")))
        }
        full.addView(btn("⌄") { full.visibility = View.GONE }.apply { textSize = 26f })
        art = roundImg(14)
        full.addView(art, LinearLayout.LayoutParams(-1, dp(290)).apply { topMargin = dp(4) })
        val tr = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(14), 0, 0) }
        val tc = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        pT = txt("", 22f, Color.WHITE, true).apply { setSingleLine(true) }; pS = txt("", 15f, GRAY).apply { setSingleLine(true) }
        tc.addView(pT); tc.addView(pS)
        tr.addView(tc, LinearLayout.LayoutParams(0, -2, 1f))
        favBtn = btn("♡") { toggleFav(current()) }.apply { textSize = 26f }
        tr.addView(favBtn)
        full.addView(tr)
        seek = SeekBar(this)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { if (user) ctrl?.seekTo(p.toLong()) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        full.addView(seek)
        timeTv = txt("0:00 / 0:00", 12f, GRAY).apply { gravity = Gravity.CENTER }
        full.addView(timeTv)
        val ctl = LinearLayout(this).apply { gravity = Gravity.CENTER }
        pShuf = btn("🔀", 1f) { ctrl?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled }; syncUi() }
        pRep = btn("🔁", 1f) { ctrl?.let { it.repeatMode = (it.repeatMode + 1) % 3 }; syncUi() }
        pPlay = btn("▶", 0f) { togglePlay() }.apply { textSize = 28f; setTextColor(Color.BLACK); background = rounded(GREEN, 40); layoutParams = LinearLayout.LayoutParams(dp(68), dp(68)).apply { setMargins(dp(8), 0, dp(8), 0) } }
        ctl.addView(pShuf); ctl.addView(btn("⏮", 1f) { ctrl?.seekToPrevious() }.apply { textSize = 24f }); ctl.addView(pPlay)
        ctl.addView(btn("⏭", 1f) { ctrl?.seekToNext() }.apply { textSize = 24f }); ctl.addView(pRep)
        full.addView(ctl)
        pLine = txt("", 17f, Color.WHITE, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(4)); setOnClickListener { openLyrics() } }
        full.addView(pLine)
        val ex = LinearLayout(this).apply { gravity = Gravity.CENTER }
        sleepBtn = btn("⏲ Dormir", 1f) { sleepDialog() }.apply { textSize = 12f }
        ex.addView(btn("📝 Letra", 1f) { openLyrics() }.apply { textSize = 12f })
        ex.addView(btn("⚡ Velocidad", 1f) { speedDialog() }.apply { textSize = 12f })
        ex.addView(sleepBtn)
        full.addView(ex)
        return full
    }

    // ================== Letras ==================
    private val lyAdapter = object : BaseAdapter() {
        override fun getCount() = lyLines.size
        override fun getItem(p: Int) = lyLines[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, v: View?, g: ViewGroup): View {
            val l = lyLines[p]
            val box = (v as? LinearLayout) ?: LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(24), dp(10), dp(24), dp(10))
                addView(TextView(this@MainActivity).apply { gravity = Gravity.CENTER })
                addView(TextView(this@MainActivity).apply { gravity = Gravity.CENTER; setTextColor(GREEN) })
            }
            val a = box.getChildAt(0) as TextView
            val b = box.getChildAt(1) as TextView
            val on = lySynced && p == lyActive
            a.text = l.text.ifBlank { "♪" }
            a.textSize = lyricSize().toFloat() * (if (on) 1.12f else 1f)
            a.setTextColor(if (!lySynced || on) Color.WHITE else Color.parseColor("#80FFFFFF"))
            a.setTypeface(null, if (on) Typeface.BOLD else Typeface.NORMAL)
            val t = if (lyShowTrans) lyTrans.getOrNull(p) else null
            b.visibility = if (t.isNullOrBlank()) View.GONE else View.VISIBLE
            b.text = t ?: ""; b.textSize = lyricSize() * 0.75f
            return box
        }
    }

    private fun buildLyrics(): View {
        lyView = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(0, dp(30), 0, dp(6)); visibility = View.GONE; isClickable = true
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.parseColor("#5A3FD0"), Color.parseColor("#0B0B12")))
        }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), 0, dp(8), 0) }
        top.addView(btn("⌄") { lyView.visibility = View.GONE }.apply { textSize = 26f })
        lyTitle = txt("", 16f, Color.WHITE, true).apply { setSingleLine(true); layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
        top.addView(lyTitle)
        lyView.addView(top)
        lyEmpty = txt("", 15f, GRAY).apply { gravity = Gravity.CENTER; setPadding(dp(28), dp(20), dp(28), dp(10)) }
        lyView.addView(lyEmpty)
        lyList = ListView(this).apply { divider = null; adapter = lyAdapter; clipToPadding = false; setPadding(0, dp(40), 0, dp(160)) }
        lyView.addView(lyList, LinearLayout.LayoutParams(-1, 0, 1f))
        val row = LinearLayout(this)
        row.addView(btn("→ ES", 1f) { translateLyrics(true) }.apply { textSize = 12f })
        row.addView(btn("→ EN", 1f) { translateLyrics(false) }.apply { textSize = 12f })
        row.addView(btn("👁 Original", 1f) { lyShowTrans = !lyShowTrans; lyAdapter.notifyDataSetChanged() }.apply { textSize = 12f })
        row.addView(btn("✎ Editar", 1f) { editLyrics() }.apply { textSize = 12f })
        row.addView(btn("🗑", 1f) { deleteLyrics() }.apply { textSize = 12f })
        lyView.addView(row)
        return lyView
    }

    private fun openLyrics() {
        val s = current() ?: run { toast("Reproduce una canción primero"); return }
        lyTitle.text = s.title + " · " + s.artist
        lyView.visibility = View.VISIBLE
        refreshLyricsUi()
    }

    private fun refreshLyricsUi() {
        lyAdapter.notifyDataSetChanged()
        lyEmpty.text = lyStatus
        lyEmpty.visibility = if (lyLines.isEmpty()) View.VISIBLE else View.GONE
        if (lyLines.isEmpty()) pLine.text = ""
    }

    private fun setLyrics(raw: String) {
        val (lines, synced) = Lyrics.parse(raw)
        lyRaw = raw; lyLines = lines; lySynced = synced; lyTrans = arrayOfNulls(lines.size); lyShowTrans = false; lyActive = -1
        lyStatus = if (lines.isEmpty()) "La letra está vacía. Toca Editar." else ""
        refreshLyricsUi()
    }

    private fun loadLyrics(s: Song) {
        if (lySong == s.id) return
        lySong = s.id; lyLines = emptyList(); lyRaw = null; lyTrans = arrayOfNulls(0); lyActive = -1; pLine.text = ""
        if (!showLyricsOn()) { lyStatus = "Las letras están ocultas. Actívalas en Ajustes."; refreshLyricsUi(); return }
        val saved = prefs.getString("lyr_${s.id}", null)
        if (saved != null) { setLyrics(saved); return }
        if (prefs.getBoolean("lyn_${s.id}", false)) { lyStatus = "Sin letra. Toca Editar para añadirla."; refreshLyricsUi(); return }
        lyStatus = "Buscando letra…"; refreshLyricsUi()
        val tree = treeUri(); val kw = keyword(); val online = prefs.getBoolean("ly_online", true)
        Thread {
            var raw: String? = null
            try { if (tree != null) raw = Lyrics.findInTree(this, tree, s.title, s.artist, kw) } catch (e: Exception) {}
            if (raw == null && online) raw = Lyrics.fetchOnline(s.title, s.artist)
            val found = raw
            runOnUiThread {
                if (lySong != s.id) return@runOnUiThread
                if (found != null) { prefs.edit().putString("lyr_${s.id}", found).apply(); setLyrics(found) }
                else { lyStatus = "No encontré la letra. Toca Editar para pegarla, o elige una carpeta en Ajustes."; refreshLyricsUi() }
            }
        }.start()
    }

    private fun translateLyrics(toSpanish: Boolean) {
        if (lyLines.isEmpty()) { toast("No hay letra para traducir"); return }
        val dst = if (toSpanish) TranslateLanguage.SPANISH else TranslateLanguage.ENGLISH
        val src = if (toSpanish) TranslateLanguage.ENGLISH else TranslateLanguage.SPANISH
        val tr = Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(src).setTargetLanguage(dst).build())
        toast("Traduciendo… la primera vez descarga el idioma")
        val song = lySong
        tr.downloadModelIfNeeded().addOnSuccessListener {
            if (lySong != song) return@addOnSuccessListener
            lyShowTrans = true
            lyTrans = arrayOfNulls(lyLines.size)
            lyLines.forEachIndexed { i, l ->
                if (l.text.isNotBlank()) tr.translate(l.text).addOnSuccessListener { t -> if (lySong == song && i < lyTrans.size) { lyTrans[i] = t; lyAdapter.notifyDataSetChanged() } }
            }
        }.addOnFailureListener { toast("No se pudo descargar el idioma. Revisa tu internet.") }
    }

    private fun editLyrics() {
        val s = current() ?: return
        val e = EditText(this).apply { setText(lyRaw ?: ""); hint = "Pega la letra aquí (texto o formato .lrc con tiempos)"; minLines = 8; gravity = Gravity.TOP }
        AlertDialog.Builder(this).setTitle("Editar letra").setView(e).setPositiveButton("Guardar") { _, _ ->
            val t = e.text.toString()
            if (t.isBlank()) { toast("La letra está vacía"); return@setPositiveButton }
            prefs.edit().putString("lyr_${s.id}", t).remove("lyn_${s.id}").apply(); setLyrics(t)
        }.setNegativeButton("Cancelar", null).show()
    }

    private fun deleteLyrics() {
        val s = current() ?: return
        AlertDialog.Builder(this).setTitle("¿Borrar la letra de esta canción?").setPositiveButton("Borrar") { _, _ ->
            prefs.edit().remove("lyr_${s.id}").putBoolean("lyn_${s.id}", true).apply()
            lyLines = emptyList(); lyRaw = null; lyStatus = "Letra borrada. Toca Editar para añadir otra."; refreshLyricsUi()
        }.setNegativeButton("Cancelar", null).show()
    }

    // ================== Ajustes ==================
    private fun buildSettings(): View {
        settings = ScrollView(this).apply { setBackgroundColor(Color.parseColor("#F2080810")); visibility = View.GONE; isClickable = true }
        setCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(34), dp(20), dp(30)) }
        settings.addView(setCol)
        return settings
    }

    private fun openSettings() { fillSettings(); settings.visibility = View.VISIBLE }

    private fun sw(t: String, key: String, def: Boolean, on: (Boolean) -> Unit = {}) = Switch(this).apply {
        text = t; setTextColor(Color.WHITE); isChecked = prefs.getBoolean(key, def); setPadding(0, dp(8), 0, dp(8))
        setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean(key, c).apply(); on(c) }
    }
    private fun sec(t: String) = txt(t, 13f, GREEN, true).apply { setPadding(0, dp(24), 0, dp(6)) }
    private fun action(t: String, f: () -> Unit) = btn(t, 0f, f).apply { gravity = Gravity.START or Gravity.CENTER_VERTICAL; background = rounded(Color.parseColor("#22FFFFFF"), 10); layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(4), 0, dp(4)) } }

    private fun fillSettings() {
        setCol.removeAllViews()
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        top.addView(btn("←") { settings.visibility = View.GONE }.apply { textSize = 24f })
        top.addView(txt("Ajustes", 24f, Color.WHITE, true))
        setCol.addView(top)
        val about = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(10), 0, 0) }
        about.addView(ImageView(this).apply { setImageBitmap(emblem(200)) }, LinearLayout.LayoutParams(dp(64), dp(64)))
        val at = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), 0, 0, 0) }
        at.addView(txt("L.E.B computing", 18f, Color.WHITE, true)); at.addView(txt("Versión 1.2", 13f, GRAY))
        about.addView(at); setCol.addView(about)

        setCol.addView(sec("LETRAS"))
        setCol.addView(sw("Mostrar letras", "ly_show", true) { lySong = -1L; syncUi() })
        setCol.addView(sw("Buscar letras en internet", "ly_online", true))
        val tree = treeUri()
        val folder = tree?.let { try { DocumentsContract.getTreeDocumentId(it).substringAfter(':').ifBlank { "Almacenamiento" } } catch (e: Exception) { "elegida" } }
        setCol.addView(action("📁  Carpeta de letras (.lrc / .txt): ${folder ?: "ninguna"}") {
            try { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION), 7) } catch (e: Exception) { toast("No se pudo abrir el selector") }
        })
        if (tree != null) setCol.addView(action("✕  Quitar carpeta de letras") { prefs.edit().remove("ly_tree").apply(); lySong = -1L; fillSettings() })
        setCol.addView(txt("Palabra clave del nombre del archivo (opcional)", 12f, GRAY).apply { setPadding(0, dp(10), 0, 0) })
        setCol.addView(EditText(this).apply {
            setText(keyword()); hint = "ej. letra"; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE); setSingleLine(true)
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { prefs.edit().putString("ly_kw", s.toString().trim()).apply(); lySong = -1L }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        })
        val sizeTv = txt("Tamaño de letra: ${lyricSize()}", 14f, Color.WHITE).apply { setPadding(0, dp(14), 0, 0) }
        setCol.addView(sizeTv)
        setCol.addView(SeekBar(this).apply {
            max = 20; progress = lyricSize() - 12
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { prefs.edit().putInt("ly_size", 12 + p).apply(); sizeTv.text = "Tamaño de letra: ${12 + p}"; lyAdapter.notifyDataSetChanged() }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })

        setCol.addView(sec("MÚSICA"))
        setCol.addView(action("🔄  Reescanear música") { if (hasAudioPerm()) scan() else toast("Falta el permiso de música") })
        setCol.addView(sw("Mostrar audios cortos (menos de 30 s)", "short", false) { if (hasAudioPerm()) scan() })
        setCol.addView(sw("Mantener el tono al cambiar la velocidad", "pitch", false) { keepPitch = it; applySpeed() })

        setCol.addView(sec("APARIENCIA"))
        setCol.addView(action("🖼  Elegir foto de fondo") {
            try { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION), 8) } catch (e: Exception) { toast("No se pudo abrir la galería") }
        })
        setCol.addView(action("🌌  Usar el fondo del espacio") { prefs.edit().remove("bg").apply(); loadBackground() })

        setCol.addView(sec("DATOS"))
        setCol.addView(action("Borrar favoritas") { prefs.edit().remove("fav").apply(); refresh(); syncUi(); toast("Favoritas borradas") })
        setCol.addView(action("Borrar todas las letras guardadas") {
            val e = prefs.edit(); prefs.all.keys.filter { it.startsWith("lyr_") || it.startsWith("lyn_") }.forEach { e.remove(it) }; e.apply()
            lySong = -1L; syncUi(); toast("Letras borradas")
        })
        setCol.addView(action("Cerrar") { settings.visibility = View.GONE }.apply { setTextColor(GREEN) })
    }

    // ================== Diálogos y estado ==================
    private fun speedDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(10), dp(20), 0) }
        val tv = TextView(this).apply { text = "Velocidad: %.2fx".format(rate); textSize = 16f }
        val sb = SeekBar(this).apply { max = 30; progress = ((rate - 0.5f) / 0.05f).toInt().coerceIn(0, 30) }
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { if (u) { setRate(0.5f + p * 0.05f); tv.text = "Velocidad: %.2fx".format(rate) } }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        val row = LinearLayout(this)
        fun preset(t: String, r: Float) = btn(t, 1f) { setRate(r); sb.progress = ((r - 0.5f) / 0.05f).toInt(); tv.text = "Velocidad: %.2fx".format(rate) }
        row.addView(preset("🐢 Slowed", 0.8f)); row.addView(preset("Normal", 1f)); row.addView(preset("🐇 Sped up", 1.25f))
        box.addView(tv); box.addView(sb); box.addView(row)
        AlertDialog.Builder(this).setTitle("Velocidad").setView(box).setPositiveButton("Listo", null).show()
    }

    private fun sleepDialog() {
        val o = arrayOf("15 minutos", "30 minutos", "45 minutos", "1 hora", "Cancelar temporizador")
        val m = intArrayOf(15, 30, 45, 60, 0)
        AlertDialog.Builder(this).setTitle("Temporizador para dormir").setItems(o) { _, i ->
            sleepAt = if (m[i] == 0) 0L else System.currentTimeMillis() + m[i] * 60000L
            if (m[i] == 0) sleepBtn.text = "⏲ Dormir"
        }.show()
    }

    private fun syncUi() {
        try {
            val c = ctrl ?: return
            val s = current()
            mini.visibility = if (s != null) View.VISIBLE else View.GONE
            if (s != null && pT.text.toString() != s.title) {
                pT.text = s.title; pS.text = s.artist; miniT.text = s.title; miniS.text = s.artist
                thumb(s, art, 600); thumb(s, miniArt, 160)
                list.invalidateViews()
            }
            if (s != null) { loadLyrics(s); if (lyView.visibility == View.VISIBLE) lyTitle.text = s.title + " · " + s.artist }
            val icon = if (c.isPlaying) "⏸" else "▶"
            pPlay.text = icon; miniPlay.text = icon
            pShuf.alpha = if (c.shuffleModeEnabled) 1f else 0.4f
            pRep.alpha = if (c.repeatMode != Player.REPEAT_MODE_OFF) 1f else 0.4f
            pRep.text = if (c.repeatMode == Player.REPEAT_MODE_ONE) "🔂" else "🔁"
            favBtn.text = if (isFav(s)) "♥" else "♡"
            favBtn.setTextColor(if (isFav(s)) GREEN else Color.WHITE)
        } catch (e: Exception) {}
    }

    private fun fmt(ms: Long) = "%d:%02d".format(ms / 60000, ms / 1000 % 60)

    private fun tick() {
        try {
            val c = ctrl
            if (c != null && c.currentMediaItem != null) {
                val d = c.duration; val pos = c.currentPosition
                if (d > 0) {
                    seek.max = d.toInt(); seek.progress = pos.toInt(); timeTv.text = "${fmt(pos)} / ${fmt(d)}"
                    miniProg.progress = (pos * 1000 / d).toInt()
                }
                if (lySynced && lyLines.isNotEmpty()) {
                    var idx = -1
                    for (i in lyLines.indices) { if (lyLines[i].timeMs <= pos + 300) idx = i else break }
                    if (idx != lyActive) {
                        lyActive = idx; lyAdapter.notifyDataSetChanged()
                        pLine.text = lyLines.getOrNull(idx)?.text ?: ""
                        if (lyView.visibility == View.VISIBLE && idx >= 0) lyList.smoothScrollToPositionFromTop(idx, lyList.height / 3)
                    }
                }
            }
            if (sleepAt > 0) {
                val left = sleepAt - System.currentTimeMillis()
                if (left <= 0) { sleepAt = 0; ctrl?.pause(); sleepBtn.text = "⏲ Dormir" } else sleepBtn.text = "⏲ ${left / 60000 + 1} min"
            }
        } catch (e: Exception) {}
        h.postDelayed({ tick() }, 500)
    }
}
