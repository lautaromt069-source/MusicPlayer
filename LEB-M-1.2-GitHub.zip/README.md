# L.E.B-M v1.2

Reproductor de música local para Android 8.0+ (incluye Android 12).

## Novedades 1.2
- Logo **L.E.B** en biblioteca y reproductor
- Letras **dinámicas** (LRC): resalta, agranda y hace scroll de la línea actual
- Fondos animados
- Workflow de GitHub listo (descomprime `MusicPlayer.zip` y genera `L.E.B-M.apk`)

## Cómo usar en tu repo Jarvis
1. Subí **solo** el archivo `MusicPlayer.zip` a la raíz del repo (o reemplazá el anterior).
2. Asegurate de que exista `.github/workflows/build.yml` (viene dentro del zip del proyecto completo, o usá el de este README).
3. Push → Actions → artefacto **L.E.B-M**.
